
import React, { useState, useEffect } from 'react';
import { LeftSidebar } from './components/LeftSidebar';
import { CenterPanel } from './components/CenterPanel';
import { RightSidebar } from './components/RightSidebar';
import { ActiveView } from './types';
import { initializeDataLayer } from './services/dataService';

function App() {
  const [activeView, setActiveView] = useState<ActiveView>(ActiveView.CallLogs);
  const [isLeftSidebarCollapsed, setIsLeftSidebarCollapsed] = useState(false);
  const [isRightSidebarCollapsed, setIsRightSidebarCollapsed] = useState(false);
  const [ivrAudioUrls, setIvrAudioUrls] = useState<Record<string, string> | null>(null);
  const [isDataLayerInitialized, setIsDataLayerInitialized] = useState(false);

  useEffect(() => {
    const init = async () => {
      await initializeDataLayer();
      setIsDataLayerInitialized(true);
    };
    init();
  }, []);

  if (!isDataLayerInitialized) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-eburon-bg text-eburon-fg">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 border-4 border-eburon-fg/50 border-t-eburon-accent rounded-full animate-spin"></div>
          <p className="text-lg">Initializing Eburon Studio...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-screen flex bg-eburon-bg text-eburon-fg overflow-hidden">
      <LeftSidebar 
        activeView={activeView}
        setActiveView={setActiveView}
        isCollapsed={isLeftSidebarCollapsed}
        setIsCollapsed={setIsLeftSidebarCollapsed}
      />
      <CenterPanel 
        activeView={activeView} 
        onIvrAudiosGenerated={setIvrAudioUrls} 
        ivrAudioUrls={ivrAudioUrls}
      />
      <RightSidebar 
        isCollapsed={isRightSidebarCollapsed}
        setIsCollapsed={setIsRightSidebarCollapsed}
        ivrAudioUrls={ivrAudioUrls}
      />
    </div>
  );
}

export default App;
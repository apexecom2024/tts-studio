
import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Agent, Voice } from '../types';
import { VOICE_PREVIEWS, TURKISH_AIRLINES_PROMPT, MOCK_AGENTS } from '../constants';
import * as dataService from '../services/dataService';
import { fetchEburonPersonas } from '../services/blandAiService';
import { uploadAgentAvatar } from '../services/supabaseService';
import { PencilIcon, PlusIcon, PlayIcon, PauseIcon, ChevronLeftIcon, AgentIcon, ImageIcon } from './icons';

const AgentEditor: React.FC<{
    agent: Agent;
    onBack: () => void;
    onSave: (updatedAgent: Agent) => void;
}> = ({ agent, onBack, onSave }) => {
    const [editedAgent, setEditedAgent] = useState<Agent>(agent);
    const [allVoices, setAllVoices] = useState<Voice[]>([]);
    const [voiceFilter, setVoiceFilter] = useState<'Prebuilt' | 'Cloned'>('Prebuilt');
    const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null);
    const [avatarFile, setAvatarFile] = useState<File | null>(null);
    const [avatarPreview, setAvatarPreview] = useState<string | null>(agent.avatarUrl);
    const [isSaving, setIsSaving] = useState(false);
    
    const audioRef = useRef<HTMLAudioElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        const loadVoices = async () => {
            const voices = await dataService.getVoices();
            setAllVoices(voices);
        };
        loadVoices();
    }, []);

    const filteredVoices = useMemo(() => {
        return allVoices.filter(v => v.type === voiceFilter);
    }, [voiceFilter, allVoices]);
    
    const handlePlayPreview = (voiceId: string) => {
        const audio = audioRef.current;
        if (!audio) return;

        if (playingVoiceId === voiceId) {
            audio.pause();
            setPlayingVoiceId(null);
        } else {
            const previewUrl = VOICE_PREVIEWS[voiceId];
            if (previewUrl) {
                audio.src = previewUrl;
                audio.play().catch(console.error);
                setPlayingVoiceId(voiceId);
            }
        }
    };

    const handleAudioEnded = () => {
        setPlayingVoiceId(null);
    };

    const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setAvatarFile(file);
            // Revoke old object URL to prevent memory leaks
            if (avatarPreview && avatarPreview.startsWith('blob:')) {
                URL.revokeObjectURL(avatarPreview);
            }
            setAvatarPreview(URL.createObjectURL(file));
        }
    };

    const handleSave = async () => {
        setIsSaving(true);
        let finalAgent = { ...editedAgent };

        if (avatarFile) {
            try {
                const newAvatarUrl = await uploadAgentAvatar(editedAgent.id, avatarFile);
                finalAgent.avatarUrl = newAvatarUrl;
            } catch (error) {
                console.error("Failed to upload avatar:", error);
                // Optionally show an error to the user
                setIsSaving(false);
                return;
            }
        }

        await dataService.updateAgent(finalAgent);
        onSave(finalAgent);
        setIsSaving(false);
        onBack();
    }

    return (
        <div className="p-8 h-full overflow-y-auto">
            <audio ref={audioRef} onEnded={handleAudioEnded} />
            <button onClick={onBack} className="flex items-center gap-2 text-eburon-fg/70 hover:text-eburon-fg mb-6">
                <ChevronLeftIcon className="w-5 h-5" />
                Back to Agents
            </button>
            <h1 className="text-3xl font-bold text-eburon-fg mb-8">Edit Agent</h1>

            <div className="space-y-6 max-w-4xl">
                {/* Agent Profile Section */}
                <div className="bg-eburon-panel p-6 rounded-xl border border-eburon-border flex items-center gap-6">
                    <input type="file" ref={fileInputRef} onChange={handleAvatarChange} accept="image/*" className="hidden" />
                    <button onClick={() => fileInputRef.current?.click()} className="relative w-24 h-24 rounded-full flex-shrink-0 group" aria-label="Upload agent avatar">
                        {avatarPreview ? (
                            <img src={avatarPreview} alt="Avatar" className="w-full h-full rounded-full object-cover" />
                        ) : (
                            <div className="w-full h-full rounded-full bg-eburon-bg border border-eburon-border flex items-center justify-center text-eburon-fg/50">
                                <AgentIcon className="w-10 h-10" />
                            </div>
                        )}
                        <div className="absolute inset-0 bg-black/50 rounded-full flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                            <ImageIcon className="w-8 h-8" />
                        </div>
                    </button>
                    <div className="flex-grow">
                        <label htmlFor="agentName" className="block text-xl font-semibold text-eburon-fg mb-2">Agent Name</label>
                        <input
                            id="agentName"
                            type="text"
                            value={editedAgent.name}
                            onChange={(e) => setEditedAgent(prev => ({ ...prev, name: e.target.value }))}
                            className="w-full bg-eburon-bg border border-eburon-border rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-eburon-accent"
                        />
                    </div>
                </div>

                {/* Voice Selection */}
                <div className="bg-eburon-panel p-6 rounded-xl border border-eburon-border">
                    <h2 className="text-xl font-semibold text-eburon-fg mb-4">Voice</h2>
                    <div className="flex border-b border-eburon-border mb-4">
                        <button onClick={() => setVoiceFilter('Prebuilt')} className={`px-4 py-2 font-semibold ${voiceFilter === 'Prebuilt' ? 'text-eburon-accent border-b-2 border-eburon-accent' : 'text-eburon-fg/60'}`}>Pre-built</button>
                        <button onClick={() => setVoiceFilter('Cloned')} className={`px-4 py-2 font-semibold ${voiceFilter === 'Cloned' ? 'text-eburon-accent border-b-2 border-eburon-accent' : 'text-eburon-fg/60'}`}>Cloned</button>
                    </div>
                    <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                        {filteredVoices.map(voice => {
                            const isSelected = editedAgent.voice === voice.id;
                            const isPlaying = playingVoiceId === voice.id;

                            return (
                                <div
                                    key={voice.id}
                                    className={`group flex items-center justify-between bg-eburon-bg p-3 rounded-lg border transition-colors ${
                                        isSelected
                                            ? 'border-eburon-accent bg-eburon-accent/20'
                                            : isPlaying
                                                ? 'border-eburon-accent/50 bg-eburon-accent/10'
                                                : 'border-transparent'
                                    }`}
                                >
                                    <label htmlFor={voice.id} className="flex items-center gap-4 cursor-pointer flex-grow">
                                        <input
                                            type="radio"
                                            name="voice"
                                            id={voice.id}
                                            checked={isSelected}
                                            onChange={() => setEditedAgent(prev => ({ ...prev, voice: voice.id }))}
                                            className="w-5 h-5 text-eburon-accent bg-eburon-bg border-eburon-border focus:ring-eburon-accent"
                                        />
                                        <div>
                                            <p className="font-semibold">{voice.name}</p>
                                            <p className="text-sm text-eburon-fg/50">{voice.provider}</p>
                                        </div>
                                    </label>
                                    <button
                                        onClick={() => handlePlayPreview(voice.id)}
                                        className={`p-2 rounded-full hover:bg-eburon-accent/20 text-eburon-accent transition-opacity ${
                                            (isPlaying || isSelected)
                                                ? 'opacity-100'
                                                : 'opacity-0 group-hover:opacity-100'
                                        }`}
                                    >
                                        {isPlaying ? <PauseIcon className="w-5 h-5" /> : <PlayIcon className="w-5 h-5" />}
                                    </button>
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* System Prompt */}
                 <div className="bg-eburon-panel p-6 rounded-xl border border-eburon-border">
                    <label htmlFor="systemPrompt" className="block text-xl font-semibold text-eburon-fg mb-3">System Prompt</label>
                    <textarea
                        id="systemPrompt"
                        value={editedAgent.systemPrompt}
                        onChange={(e) => setEditedAgent(prev => ({ ...prev, systemPrompt: e.target.value }))}
                        rows={12}
                        className="w-full bg-eburon-bg border border-eburon-border rounded-lg p-3 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-eburon-accent"
                    />
                </div>
                
                {/* Actions */}
                <div className="flex justify-end gap-4">
                    <button onClick={onBack} className="bg-eburon-panel hover:bg-white/10 text-white font-bold py-3 px-6 rounded-lg transition-colors duration-150">Cancel</button>
                    <button onClick={handleSave} disabled={isSaving} className="bg-eburon-accent hover:bg-eburon-accent-dark text-white font-bold py-3 px-6 rounded-lg transition-colors duration-150 flex items-center disabled:bg-gray-600">
                        {isSaving && <div className="w-5 h-5 border-2 border-white/50 border-t-white rounded-full animate-spin mr-2"></div>}
                        {isSaving ? 'Saving...' : 'Save Changes'}
                    </button>
                </div>
            </div>
        </div>
    )
}


const AgentsView: React.FC = () => {
    const [agents, setAgents] = useState<Agent[]>([]);
    const [allVoices, setAllVoices] = useState<Voice[]>([]);
    const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);


    useEffect(() => {
        const loadInitialData = async () => {
            setIsLoading(true);
            setError(null);
            try {
                // Fetch voices first to ensure they are available for new agents.
                const voices = await dataService.getVoices();
                setAllVoices(voices);

                let dbAgents = await dataService.getAgents();
                if (dbAgents.length === 0) {
                    setError("No agents found in local cache. Attempting to fetch from Eburon TTS...");
                    const personas = await fetchEburonPersonas();
                    const newAgents: Agent[] = personas.map(p => ({
                        id: p.persona_id,
                        name: p.name,
                        voice: p.voice_id || (voices.length > 0 ? voices[0].id : ''),
                        systemPrompt: p.system_prompt || TURKISH_AIRLINES_PROMPT,
                        thinkingMode: false,
                        avatarUrl: null,
                    }));
                    await dataService.upsertAgents(newAgents);
                    dbAgents = await dataService.getAgents();
                    setError(null);
                }
                setAgents(dbAgents);
            } catch (err: any) {
                console.error("Failed to load agents from API:", err);
                setError(`Failed to connect to Eburon TTS. Loading from local cache.`);
                
                // If API fetch fails, ensure voices are loaded from cache for the editor
                const cachedVoices = await dataService.getVoices();
                setAllVoices(cachedVoices);

                // Then, attempt to load agents from cache
                let cachedAgents = await dataService.getAgents();
                if (cachedAgents.length === 0) {
                    // If cache is empty (first load scenario), populate with mocks.
                    console.log("Agent cache is empty. Populating with mock agents.");
                    await dataService.upsertAgents(MOCK_AGENTS);
                    cachedAgents = await dataService.getAgents();
                }
                setAgents(cachedAgents);
            } finally {
                setIsLoading(false);
            }
        };

        loadInitialData();
    }, []);
    

    const handleSaveAgent = (updatedAgent: Agent) => {
        setAgents(prev => prev.map(a => a.id === updatedAgent.id ? updatedAgent : a));
    };

    const handleCreateAgent = async () => {
        if (allVoices.length === 0) {
            setError("Cannot create agent: No voices available.");
            return;
        }
        const newAgent: Agent = {
            id: `agent-${Date.now()}`,
            name: `New Agent #${agents.length + 1}`,
            voice: allVoices[0].id,
            systemPrompt: TURKISH_AIRLINES_PROMPT,
            thinkingMode: false,
            avatarUrl: null,
        };
        await dataService.upsertAgents([newAgent]);
        setAgents(prev => [newAgent, ...prev]);
        setSelectedAgent(newAgent);
    };

    if (isLoading) {
        return <div className="h-full flex items-center justify-center"><div className="w-12 h-12 border-4 border-eburon-fg/50 border-t-eburon-accent rounded-full animate-spin"></div></div>;
    }

    if (selectedAgent) {
        return <AgentEditor agent={selectedAgent} onBack={() => setSelectedAgent(null)} onSave={handleSaveAgent} />
    }

    return (
        <div className="p-8 h-full overflow-y-auto">
            <div className="flex justify-between items-center mb-8">
                <h1 className="text-3xl font-bold text-eburon-fg">Agents</h1>
                <button onClick={handleCreateAgent} className="bg-eburon-accent hover:bg-eburon-accent-dark text-white font-bold py-2 px-4 rounded-lg flex items-center gap-2 transition-colors duration-150">
                    <PlusIcon className="w-5 h-5" />
                    Create New Agent
                </button>
            </div>
            
            {error && <div className="mb-4 bg-eburon-warn/20 border border-eburon-warn text-eburon-warn p-3 rounded-lg text-sm">{error}</div>}

            <div className="bg-eburon-panel rounded-xl border border-eburon-border overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-eburon-panel border-b border-eburon-border">
                        <tr>
                            <th className="p-4 font-semibold">Name</th>
                            <th className="p-4 font-semibold">Voice</th>
                            <th className="p-4 font-semibold">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {agents.map(agent => {
                            const voice = allVoices.find(v => v.id === agent.voice);
                            return (
                                <tr key={agent.id} className="border-b border-eburon-border last:border-b-0">
                                    <td className="p-4 flex items-center gap-3">
                                        {agent.avatarUrl ? (
                                            <img src={agent.avatarUrl} alt={agent.name} className="w-10 h-10 rounded-full object-cover" />
                                        ) : (
                                            <div className="w-10 h-10 rounded-full bg-eburon-accent/20 flex items-center justify-center text-eburon-accent">
                                                <AgentIcon className="w-5 h-5"/>
                                            </div>
                                        )}
                                        {agent.name}
                                    </td>
                                    <td className="p-4 text-eburon-fg/80">{voice?.name || 'Unknown'}</td>
                                    <td className="p-4">
                                        <button onClick={() => setSelectedAgent(agent)} className="text-eburon-accent hover:text-eburon-accent-dark p-2 rounded-md hover:bg-eburon-accent/10">
                                            <PencilIcon className="w-5 h-5" />
                                        </button>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default AgentsView;
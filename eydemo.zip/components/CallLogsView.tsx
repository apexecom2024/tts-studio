
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { CallLog } from '../types';
import { fetchRecording } from '../services/blandAiService';
import * as dataService from '../services/dataService';
import { MOCK_CALL_LOGS, AUDIO_ASSETS } from '../constants';
import { SearchIcon, PhoneIcon, UserIcon, AgentIcon } from './icons';

const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
};

const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
        hour12: true,
    });
};

const CallDetailView: React.FC<{ call: CallLog }> = ({ call }) => {
    const [audioUrl, setAudioUrl] = useState<string | null>(null);
    const [isLoadingAudio, setIsLoadingAudio] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [activeSegmentIndex, setActiveSegmentIndex] = useState<number>(-1);
    
    const audioRef = useRef<HTMLAudioElement>(null);
    const transcriptContainerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        let isMounted = true;
        let objectUrl: string | null = null;
        
        const loadRecording = async () => {
            setIsLoadingAudio(true);
            setError(null);
            setAudioUrl(null); // Clear previous audio

            // Don't fetch if there's no call ID.
            if (!call.call_id) {
                setError("Call has no ID.");
                setIsLoadingAudio(false);
                return;
            }

            try {
                const blob = await fetchRecording(call.call_id);
                objectUrl = URL.createObjectURL(blob);
                if (isMounted) {
                    setAudioUrl(objectUrl);
                }
            } catch (err: any) {
                if (isMounted) {
                    console.error("Failed to load recording:", err);
                    setError(err.message || "Could not load audio recording.");
                }
            } finally {
                if (isMounted) {
                    setIsLoadingAudio(false);
                }
            }
        };

        loadRecording();

        return () => {
            isMounted = false;
            if (objectUrl) {
                URL.revokeObjectURL(objectUrl);
            }
            setActiveSegmentIndex(-1);
        };
    }, [call]);

    const handleTimeUpdate = () => {
        if (!audioRef.current || !call.transcript) return;
        const currentTime = audioRef.current.currentTime;
        
        let newActiveIndex = -1;
        for (let i = call.transcript.length - 1; i >= 0; i--) {
            if (currentTime >= call.transcript[i].start_time) {
                newActiveIndex = i;
                break;
            }
        }

        if (newActiveIndex !== activeSegmentIndex) {
            setActiveSegmentIndex(newActiveIndex);
            const activeElement = transcriptContainerRef.current?.children[newActiveIndex] as HTMLElement;
            if (activeElement) {
                activeElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }
    };

    return (
        <div className="p-6 flex flex-col h-full bg-eburon-panel border-l border-eburon-border">
            <h2 className="text-2xl font-bold text-eburon-fg mb-4">Call Details</h2>
            <div className="mb-4 text-sm text-eburon-fg/80">
                <p><strong>From:</strong> {call.from}</p>
                <p><strong>To:</strong> {call.to}</p>
                <p><strong>Date:</strong> {formatDate(call.created_at)}</p>
                <p><strong>Duration:</strong> {formatDuration(call.duration)}</p>
            </div>
            
            <div className="mb-4">
                {isLoadingAudio && <div className="h-14 bg-eburon-bg rounded-lg flex items-center justify-center text-sm text-eburon-fg/60">Loading Audio...</div>}
                {error && <div className="h-14 bg-red-900/50 border border-red-500 text-red-300 rounded-lg flex items-center justify-center text-sm">{error}</div>}
                {audioUrl && <audio ref={audioRef} src={audioUrl} controls className="w-full" onTimeUpdate={handleTimeUpdate} />}
            </div>

            <h3 className="text-xl font-semibold text-eburon-fg mb-3">Transcript</h3>
            <div ref={transcriptContainerRef} className="flex-grow bg-eburon-bg p-4 rounded-lg overflow-y-auto space-y-4">
                {call.transcript && call.transcript.map((segment, index) => (
                    <div key={index} className={`flex gap-3 items-start transition-all duration-300 p-3 rounded-lg ${activeSegmentIndex === index ? 'bg-eburon-accent/20 scale-[1.01]' : 'bg-transparent'}`}>
                        <div className={`w-8 h-8 rounded-full flex-shrink-0 grid place-items-center ${segment.user === 'agent' ? 'bg-eburon-accent' : 'bg-gray-500'}`}>
                           {segment.user === 'agent' ? <AgentIcon className="w-5 h-5 text-white" /> : <UserIcon className="w-5 h-5 text-white" />}
                        </div>
                        <div>
                            <span className="font-bold text-sm capitalize">{segment.user}</span>
                            <p className="text-eburon-fg/90">{segment.text}</p>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

const CallLogsView: React.FC = () => {
    const [callLogs, setCallLogs] = useState<CallLog[]>([]);
    const [selectedCall, setSelectedCall] = useState<CallLog | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        const loadLogs = async () => {
            setIsLoading(true);
            setError(null);
            try {
                let logs = await dataService.getCallLogs();
                if (logs.length === 0) {
                    await dataService.upsertCallLogs(MOCK_CALL_LOGS);
                    logs = await dataService.getCallLogs();
                }
                setCallLogs(logs);
                if (logs.length > 0) {
                    setSelectedCall(logs[0]);
                }
            } catch (err: any) {
                console.error("Failed to load call logs:", err);
                setError(`Could not retrieve call logs: ${err.message}`);
            } finally {
                setIsLoading(false);
            }
        };
        loadLogs();
    }, []);

    const filteredLogs = useMemo(() => {
        if (!searchTerm) return callLogs;
        const lowercasedFilter = searchTerm.toLowerCase();
        return callLogs.filter(log => 
            log.from.includes(lowercasedFilter) || 
            log.to.includes(lowercasedFilter) ||
            log.concatenated_transcript.toLowerCase().includes(lowercasedFilter)
        );
    }, [callLogs, searchTerm]);

    if (isLoading) {
        return <div className="h-full flex items-center justify-center"><div className="w-12 h-12 border-4 border-eburon-fg/50 border-t-eburon-accent rounded-full animate-spin"></div></div>;
    }

    if (error) {
        return <div className="p-8 text-center text-red-400">{error}</div>;
    }

    return (
        <div className="flex h-full">
            <div className="w-1/3 min-w-[350px] max-w-[450px] flex flex-col border-r border-eburon-border">
                <div className="p-4 border-b border-eburon-border">
                    <h1 className="text-2xl font-bold mb-4">Call Logs</h1>
                     <div className="relative">
                        <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-eburon-fg/50" />
                        <input type="text" placeholder="Search by number or transcript..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full bg-eburon-panel border border-eburon-border rounded-lg pl-10 pr-4 py-2 focus:outline-none focus:ring-2 focus:ring-eburon-accent" />
                    </div>
                </div>
                <div className="flex-grow overflow-y-auto">
                    {filteredLogs.map(log => (
                        <button 
                            key={log.call_id} 
                            onClick={() => setSelectedCall(log)}
                            className={`w-full text-left p-4 border-b border-eburon-border hover:bg-eburon-panel transition-colors ${selectedCall?.call_id === log.call_id ? 'bg-eburon-accent/10' : ''}`}
                        >
                            <div className="flex justify-between items-center mb-1">
                                <span className="font-semibold">{log.to}</span>
                                <span className="text-xs text-eburon-fg/60">{formatDuration(log.duration)}</span>
                            </div>
                            <p className="text-sm text-eburon-fg/70">From: {log.from}</p>
                            <p className="text-xs text-eburon-fg/50 mt-1">{formatDate(log.created_at)}</p>
                        </button>
                    ))}
                </div>
            </div>
            <div className="flex-grow">
                {selectedCall ? (
                    <CallDetailView call={selectedCall} />
                ) : (
                    <div className="h-full flex flex-col items-center justify-center text-eburon-fg/60">
                        <PhoneIcon className="w-16 h-16 mb-4" />
                        <h2 className="text-xl font-semibold">No Call Selected</h2>
                        <p>Select a call from the list to view its details.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default CallLogsView;
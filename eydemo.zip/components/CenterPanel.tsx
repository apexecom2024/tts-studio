


import React from 'react';
import { ActiveView } from '../types';
import { MOCK_TEMPLATES } from '../constants';
import ChatbotView from './ChatbotView';
import AgentsView from './AgentsView';
import IVRView from './IVRView';
import VoicesView from './VoicesView';
import CallLogsView from './CallLogsView';
import TTSStudioView from './TTSStudioView';

interface CenterPanelProps {
  activeView: ActiveView;
  onIvrAudiosGenerated: (urls: Record<string, string> | null) => void;
  ivrAudioUrls: Record<string, string> | null;
}

const PlaceholderView: React.FC<{ title: string }> = ({ title }) => (
    <div className="p-8">
        <h1 className="text-3xl font-bold text-eburon-fg mb-4">{title}</h1>
        <p className="text-eburon-fg/70">
            This is a placeholder for the {title} view. Functionality for this section can be built out here.
        </p>
    </div>
);


const TemplateViewer: React.FC = () => {
    const template = MOCK_TEMPLATES[0];
    return (
        <div className="p-8 h-full overflow-y-auto">
            <h1 className="text-3xl font-bold text-eburon-fg mb-2">{template.name}</h1>
            <p className="text-eburon-fg/70 mb-6">{template.description}</p>
            
            <div className="mb-6">
                <h2 className="text-xl font-semibold text-eburon-fg mb-3">Use Cases</h2>
                <div className="flex flex-wrap gap-3">
                    {template.useCases.map(uc => (
                        <span key={uc} className="bg-eburon-panel border border-eburon-border text-eburon-accent px-3 py-1 rounded-full text-sm">{uc}</span>
                    ))}
                </div>
            </div>

            <div className="mb-6">
                <h2 className="text-xl font-semibold text-eburon-fg mb-3">System Prompt</h2>
                <div className="bg-eburon-panel p-4 rounded-xl border border-eburon-border">
                    <p className="text-eburon-fg/90 whitespace-pre-wrap font-mono text-sm">{template.systemPrompt}</p>
                </div>
            </div>

            <button className="bg-eburon-accent hover:bg-eburon-accent-dark text-white font-bold py-3 px-6 rounded-lg transition-colors duration-150">
                Use This Template
            </button>
        </div>
    );
};


export const CenterPanel: React.FC<CenterPanelProps> = ({ activeView, onIvrAudiosGenerated, ivrAudioUrls }) => {
  const renderContent = () => {
    switch (activeView) {
      case ActiveView.Templates:
        return <TemplateViewer />;
      case ActiveView.Chatbot:
        return <ChatbotView />;
      case ActiveView.Agents:
        return <AgentsView />;
      case ActiveView.Voices:
        return <VoicesView />;
      case ActiveView.IVR:
        return <IVRView onIvrAudiosGenerated={onIvrAudiosGenerated} ivrAudioUrls={ivrAudioUrls} />;
      case ActiveView.CallLogs:
        return <CallLogsView />;
      case ActiveView.TTSStudio:
        return <TTSStudioView />;
      default:
        return <IVRView onIvrAudiosGenerated={onIvrAudiosGenerated} ivrAudioUrls={ivrAudioUrls} />;
    }
  };

  return <main className="flex-1 bg-eburon-bg overflow-hidden">{renderContent()}</main>;
};

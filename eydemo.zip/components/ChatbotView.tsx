import React, { useState, useRef, useCallback, useEffect } from 'react';
import { ChatMessage, GroundingChunk } from '../types';
import { sendMessageStreamToGemini, generateImageWithGemini } from '../services/geminiService';
import { SendIcon, PaperclipIcon, SearchIcon } from './icons';
import { EBURON_SYSTEM_PROMPT } from '../constants';

const ChatbotView: React.FC = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [useSearchGrounding, setUseSearchGrounding] = useState(false);

    const fileInputRef = useRef<HTMLInputElement>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages]);

    const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files && event.target.files[0]) {
            const file = event.target.files[0];
            setImageFile(file);
            setImagePreview(URL.createObjectURL(file));
        }
    };

    const removeImage = () => {
        setImageFile(null);
        setImagePreview(null);
        if(fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleSend = useCallback(async () => {
        if (!input.trim() && !imageFile) return;
        
        const userMessage: ChatMessage = {
            id: Date.now().toString(),
            role: 'user',
            text: input,
            image: imagePreview || undefined,
        };
        
        const modelMessagePlaceholder: ChatMessage = {
            id: (Date.now() + 1).toString(),
            role: 'model',
            text: '',
        };
        
        setMessages(prev => [...prev, userMessage]);
        setIsLoading(true);

        const currentInput = input;
        const currentImageFile = imageFile;
        const history = messages;
        
        setInput('');
        setImageFile(null);
        setImagePreview(null);
        if(fileInputRef.current) fileInputRef.current.value = "";

        const creationKeywords = ['create', 'draw', 'generate', 'make', 'design', 'paint', 'sketch'];
        const editingKeywords = ['edit', 'modify', 'change', 'add', 'remove', 'put', 'replace', 'enhance', 'fix'];
        const lowercasedInput = currentInput.toLowerCase();

        const isCreationRequest = !currentImageFile && creationKeywords.some(keyword => lowercasedInput.includes(keyword));
        const isEditingRequest = !!currentImageFile && (editingKeywords.some(keyword => lowercasedInput.includes(keyword)) || !currentInput.trim());

        if (isCreationRequest || isEditingRequest) {
            // --- Image Generation / Editing Logic ---
            const loadingText = currentImageFile ? `Editing your image...` : `Generating your image...`;
            modelMessagePlaceholder.text = loadingText;
            setMessages(prev => [...prev, modelMessagePlaceholder]);

            try {
                const generatedImageUrl = await generateImageWithGemini(currentInput, currentImageFile);
                
                const finalMessage: ChatMessage = {
                    id: modelMessagePlaceholder.id,
                    role: 'model',
                    text: currentImageFile ? 'Here is the edited image:' : 'Here is the image you requested:',
                    image: generatedImageUrl,
                };

                setMessages(prev => {
                    const newMessages = [...prev];
                    const lastMsgIndex = newMessages.length - 1;
                    newMessages[lastMsgIndex] = finalMessage;
                    return newMessages;
                });

            } catch (error: any) {
                setMessages(prev => {
                    const newMessages = [...prev];
                    const lastMessage = newMessages[newMessages.length - 1];
                    if (lastMessage && lastMessage.role === 'model') {
                        lastMessage.text = error.message || "Sorry, I couldn't generate the image.";
                    }
                    return newMessages;
                });
            } finally {
                setIsLoading(false);
            }

        } else {
            // --- Text / Recognition Logic (Streaming) ---
            const startTime = performance.now();
            setMessages(prev => [...prev, modelMessagePlaceholder]);

            try {
                const stream = await sendMessageStreamToGemini(history, currentInput, currentImageFile, useSearchGrounding, EBURON_SYSTEM_PROMPT);

                let fullText = '';
                let groundingChunks: GroundingChunk[] | undefined;

                for await (const chunk of stream) {
                    if (chunk.candidates?.[0]?.groundingMetadata?.groundingChunks) {
                        groundingChunks = chunk.candidates[0].groundingMetadata.groundingChunks as GroundingChunk[];
                    }

                    const chunkText = chunk.text;
                    for (const char of chunkText) {
                        fullText += char;
                        setMessages(prev => {
                            const newMessages = [...prev];
                            const lastMessage = newMessages[newMessages.length - 1];
                            if (lastMessage && lastMessage.role === 'model') {
                                lastMessage.text = fullText;
                                if (groundingChunks) {
                                    lastMessage.groundingChunks = groundingChunks;
                                }
                            }
                            return newMessages;
                        });
                        await new Promise(resolve => setTimeout(resolve, 2));
                    }
                }

                const endTime = performance.now();
                const durationSeconds = (endTime - startTime) / 1000;
                const words = fullText.split(/\s+/).filter(Boolean).length;
                const chars = fullText.length;
                
                const speedWps = durationSeconds > 0.01 ? parseFloat((words / durationSeconds).toFixed(1)) : words * 100;
                const speedCps = durationSeconds > 0.01 ? parseFloat((chars / durationSeconds).toFixed(1)) : chars * 100;
                const tokens = Math.round(chars / 4);
                const energyKwh = tokens * 0.0000004;

                setMessages(prev => {
                    const newMessages = [...prev];
                    const lastMessage = newMessages[newMessages.length - 1];
                    if (lastMessage && lastMessage.role === 'model') {
                        lastMessage.stats = { tokens, speedWps, speedCps, energyKwh };
                    }
                    return newMessages;
                });

            } catch (error: any) {
                setMessages(prev => {
                    const newMessages = [...prev];
                    const lastMessage = newMessages[newMessages.length - 1];
                    if (lastMessage && lastMessage.role === 'model') {
                        lastMessage.text = error.message || "Sorry, I encountered an error. Please try again.";
                    }
                    return newMessages;
                });
            } finally {
                setIsLoading(false);
            }
        }
    }, [input, imageFile, imagePreview, messages, useSearchGrounding]);


    return (
        <div className="h-full flex flex-col bg-eburon-bg text-eburon-fg">
            <header className="p-4 border-b border-eburon-border flex justify-between items-center">
                <h1 className="text-xl font-bold">Eburon Assistant</h1>
                <div className="flex items-center gap-4">
                    <label 
                        htmlFor="search-grounding-toggle" 
                        className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-colors cursor-pointer ${useSearchGrounding ? 'bg-eburon-accent text-white' : 'bg-eburon-panel hover:bg-white/10'}`}
                        title="Toggle Search Grounding"
                    >
                        <SearchIcon className="w-5 h-5"/>
                        <span>Web Search</span>
                        <div className="relative">
                            <input type="checkbox" id="search-grounding-toggle" className="sr-only" checked={useSearchGrounding} onChange={() => setUseSearchGrounding(!useSearchGrounding)} />
                            <div className={`w-9 h-5 rounded-full transition-colors ${useSearchGrounding ? 'bg-white/30' : 'bg-gray-500'}`}></div>
                            <div className={`absolute left-0.5 top-0.5 w-4 h-4 bg-white rounded-full shadow-md transition-transform ${useSearchGrounding ? 'translate-x-4' : ''}`}></div>
                        </div>
                    </label>
                </div>
            </header>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {messages.map((msg) => (
                    <div key={msg.id} className={`flex gap-4 items-start ${msg.role === 'user' ? 'justify-end' : ''}`}>
                        {msg.role === 'model' && <div className="w-8 h-8 rounded-full bg-eburon-accent flex items-center justify-center font-bold text-white text-sm flex-shrink-0">E</div>}
                        <div className={`max-w-xl p-4 rounded-xl ${msg.role === 'user' ? 'bg-eburon-accent text-white rounded-br-none' : 'bg-eburon-panel rounded-bl-none'}`}>
                            {msg.image && <img src={msg.image} alt="content" className="rounded-lg mb-2 max-w-xs"/>}
                            {isLoading && msg.text.includes('Generating your image...') && msg.role === 'model' && (
                                <div className="flex items-center gap-2">
                                    <div className="w-4 h-4 border-2 border-eburon-fg/50 border-t-eburon-accent rounded-full animate-spin"></div>
                                    <p className="whitespace-pre-wrap">{msg.text}</p>
                                </div>
                            )}
                            {isLoading && msg.text === '' && msg.role === 'model' && (
                                <div className="w-2.5 h-5 bg-eburon-fg animate-pulse"></div>
                            )}
                            {!(isLoading && (msg.text.includes('Generating your image...') || msg.text === '')) && <p className="whitespace-pre-wrap">{msg.text}</p>}
                            {msg.groundingChunks && msg.groundingChunks.length > 0 && (
                                <div className="mt-4 pt-3 border-t border-white/20">
                                    <h4 className="text-xs font-semibold mb-2">Sources:</h4>
                                    <div className="flex flex-col gap-2">
                                        {msg.groundingChunks.map((chunk, index) => chunk.web && chunk.web.uri && (
                                            <a href={chunk.web.uri} target="_blank" rel="noopener noreferrer" key={index} className="text-xs text-eburon-fg/80 hover:underline truncate">
                                                {chunk.web.title || chunk.web.uri}
                                            </a>
                                        ))}
                                    </div>
                                </div>
                            )}
                            {msg.role === 'model' && msg.text && !msg.image && msg.stats && (
                                <div className="mt-3 pt-2 border-t border-eburon-border/30 font-mono text-eburon-fg/60" style={{ fontSize: '8px', lineHeight: '1.4' }}>
                                    <div>Eburon RX 9060 XT</div>
                                    <div>Token Used: {msg.stats.tokens}</div>
                                    <div>Speed: {msg.stats.speedWps} w/s | {msg.stats.speedCps} c/s</div>
                                    <div>Energy: {msg.stats.energyKwh.toFixed(6)} kWh</div>
                                </div>
                            )}
                        </div>
                    </div>
                ))}
                <div ref={messagesEndRef} />
            </div>

            <div className="p-4 border-t border-eburon-border">
                 {imagePreview && (
                    <div className="relative w-24 h-24 mb-2 p-1 border border-eburon-border rounded-lg">
                        <img src={imagePreview} alt="Preview" className="w-full h-full object-cover rounded"/>
                        <button onClick={removeImage} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">&times;</button>
                    </div>
                )}
                <div className="bg-eburon-panel rounded-xl flex items-center p-2">
                    <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageChange}
                        ref={fileInputRef}
                        className="hidden"
                    />
                    <button onClick={() => fileInputRef.current?.click()} className="p-3 text-eburon-fg/70 hover:text-eburon-fg">
                        <PaperclipIcon className="w-6 h-6" />
                    </button>
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && !isLoading && handleSend()}
                        placeholder={'Type a message or describe an image to create...'}
                        className="flex-1 bg-transparent focus:outline-none px-2"
                        disabled={isLoading}
                    />
                    <button onClick={handleSend} disabled={isLoading || (!input.trim() && !imageFile)} className="p-3 rounded-lg bg-eburon-accent text-white disabled:bg-gray-500 transition-colors">
                        <SendIcon className="w-6 h-6" />
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ChatbotView;
import React, { useState } from 'react';
import { generateSpeechFromText } from '../services/geminiService';
import { uploadIvrAudio } from '../services/supabaseService';
import { decode, audioBufferToWav } from '../utils/audioUtils';
import { PlusIcon } from './icons';

interface IVRMenu {
    id: string;
    key: string;
    prompt: string;
}

const initialMenus: IVRMenu[] = [
    { id: 'ivr_menu_1', key: '1', prompt: 'For sales and new inquiries, please press 1.' },
    { id: 'ivr_menu_2', key: '2', prompt: 'For technical support or to check the status of an existing ticket, press 2.' },
    { id: 'ivr_menu_3', key: '3', prompt: 'For billing and account services, press 3.' },
    { id: 'ivr_menu_0', key: '0', prompt: 'To speak with an operator, please press 0.' },
];

type GenerationStatus = 'idle' | 'generating' | 'uploading' | 'success' | 'error';
type MenuGenerationStatus = Record<string, 'pending' | 'generating' | 'uploading' | 'done' | 'error'>;

const IVRView: React.FC<{
    onIvrAudiosGenerated: (urls: Record<string, string> | null) => void;
    ivrAudioUrls: Record<string, string> | null;
}> = ({ onIvrAudiosGenerated, ivrAudioUrls }) => {

    const [menus, setMenus] = useState<IVRMenu[]>(initialMenus);
    const [status, setStatus] = useState<GenerationStatus>('idle');
    const [menuStatus, setMenuStatus] = useState<MenuGenerationStatus>({});
    const [error, setError] = useState<string | null>(null);

    const handleMenuChange = (id: string, field: 'key' | 'prompt', value: string) => {
        setMenus(prevMenus =>
            prevMenus.map(menu =>
                menu.id === id ? { ...menu, [field]: value } : menu
            )
        );
    };

    const addMenu = () => {
        const newKey = (Math.max(0, ...menus.map(m => parseInt(m.key, 10)).filter(Number.isFinite)) + 1).toString();
        const newMenu: IVRMenu = {
            id: `ivr_menu_${Date.now()}`,
            key: newKey,
            prompt: 'New menu option prompt.'
        };
        setMenus(prev => [...prev, newMenu]);
    };

    const handleGenerateAudios = async () => {
        setStatus('generating');
        setError(null);

        const initialMenuStatus: MenuGenerationStatus = {};
        menus.forEach(menu => {
            initialMenuStatus[menu.id] = 'pending';
        });
        setMenuStatus(initialMenuStatus);

        const generatedUrls: Record<string, string> = {};
        let hasError = false;

        for (const menu of menus) {
            let audioContext: AudioContext | null = null;
            try {
                setMenuStatus(prev => ({ ...prev, [menu.id]: 'generating' }));
                const base64Audio = await generateSpeechFromText(menu.prompt);
                if (!base64Audio) throw new Error("AI service returned no audio data.");

                audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
                const pcmData = decode(base64Audio);
                const dataInt16 = new Int16Array(pcmData.buffer);
                const buffer = audioContext.createBuffer(1, dataInt16.length, 24000);
                const channelData = buffer.getChannelData(0);
                for (let i = 0; i < dataInt16.length; i++) {
                    channelData[i] = dataInt16[i] / 32768.0;
                }
                const wavBlob = audioBufferToWav(buffer);
                
                setMenuStatus(prev => ({ ...prev, [menu.id]: 'uploading' }));
                const publicUrl = await uploadIvrAudio(menu.id, wavBlob);
                generatedUrls[menu.id] = publicUrl;
                setMenuStatus(prev => ({ ...prev, [menu.id]: 'done' }));
            } catch (err: any) {
                console.error(`Failed to generate audio for menu ${menu.key}:`, err);
                hasError = true;
                setMenuStatus(prev => ({ ...prev, [menu.id]: 'error' }));
            } finally {
                if (audioContext) {
                    audioContext.close().catch(console.error);
                }
            }
        }

        if (hasError) {
            setError("Some audio files failed to generate. Please check the console for details.");
            setStatus('error');
        } else {
            setStatus('success');
        }
        onIvrAudiosGenerated(generatedUrls);
    };
    
     const getStatusIndicator = (id: string) => {
        const s = menuStatus[id];
        switch (s) {
            case 'generating':
            case 'uploading':
                return <div className="w-4 h-4 border-2 border-eburon-fg/50 border-t-eburon-accent rounded-full animate-spin"></div>;
            case 'done':
                return <div className="w-4 h-4 rounded-full bg-eburon-ok"></div>;
            case 'error':
                 return <div className="w-4 h-4 rounded-full bg-eburon-warn"></div>;
            default:
                 return <div className="w-4 h-4 rounded-full bg-eburon-border"></div>;
        }
    };


    return (
        <div className="p-8 h-full overflow-y-auto">
            <h1 className="text-3xl font-bold text-eburon-fg mb-2">IVR Menu Configuration</h1>
            <p className="text-eburon-fg/70 mb-8">
                Define the menu options for your Interactive Voice Response system. AI will generate the audio for each prompt.
            </p>

            <div className="space-y-4 max-w-4xl">
                {menus.map((menu) => (
                    <div key={menu.id} className="bg-eburon-panel p-4 rounded-xl border border-eburon-border flex items-start gap-4">
                         <div className="flex items-center gap-2 pt-3">
                            {status !== 'idle' && getStatusIndicator(menu.id)}
                            <input
                                type="text"
                                value={menu.key}
                                onChange={(e) => handleMenuChange(menu.id, 'key', e.target.value)}
                                className="bg-eburon-bg border border-eburon-border rounded-lg p-2 w-16 text-center font-bold text-lg"
                                placeholder="Key"
                            />
                         </div>
                        <textarea
                            value={menu.prompt}
                            onChange={(e) => handleMenuChange(menu.id, 'prompt', e.target.value)}
                            rows={3}
                            className="flex-1 bg-eburon-bg border border-eburon-border rounded-lg p-2 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-eburon-accent"
                            placeholder="Enter prompt text..."
                        />
                    </div>
                ))}

                <button onClick={addMenu} className="flex items-center gap-2 text-eburon-accent hover:text-eburon-accent-dark font-semibold p-2">
                    <PlusIcon className="w-5 h-5" />
                    Add Menu Option
                </button>
            </div>

            <div className="mt-8">
                <button
                    onClick={handleGenerateAudios}
                    disabled={status === 'generating' || status === 'uploading'}
                    className="bg-eburon-accent hover:bg-eburon-accent-dark text-white font-bold py-3 px-6 rounded-lg transition-colors duration-150 disabled:bg-gray-600"
                >
                    {status === 'generating' || status === 'uploading' ? 'Generating...' : 'Generate All Audio Prompts'}
                </button>
                {status === 'error' && <p className="text-red-400 mt-2">{error}</p>}
                {status === 'success' && <p className="text-eburon-ok mt-2">Audio generation complete. You can now test the IVR in the dialer.</p>}
            </div>
        </div>
    );
};

export default IVRView;

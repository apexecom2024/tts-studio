import React, { useState, useEffect, useRef } from 'react';
import { Agent } from '../types';
import * as dataService from '../services/dataService';
import { startEburonTtsCall } from '../services/blandAiService';
import { PhoneIcon, DeleteIcon, MuteIcon, SpeakerIcon, AddCallIcon, KeypadIcon, VideoIcon, ContactsIcon } from './icons';
import { AUDIO_ASSETS } from '../constants';

type CallStatus = 'idle' | 'dialing' | 'ringing' | 'connected' | 'ended' | 'error';

export const IphoneSimulator: React.FC<{ ivrAudioUrls: Record<string, string> | null }> = ({ ivrAudioUrls }) => {
  const [number, setNumber] = useState('');
  const [status, setStatus] = useState<CallStatus>('idle');
  const [callDuration, setCallDuration] = useState(0);
  const [callId, setCallId] = useState<string | null>(null);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [selectedAgentId, setSelectedAgentId] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  const audioRef = useRef<HTMLAudioElement>(null);
  // FIX: Changed NodeJS.Timeout to number for browser compatibility. `setInterval` in browsers returns a number.
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    const loadAgents = async () => {
      const fetchedAgents = await dataService.getAgents();
      setAgents(fetchedAgents);
      if (fetchedAgents.length > 0) {
        setSelectedAgentId(fetchedAgents[0].id);
      }
    };
    loadAgents();
  }, []);

  useEffect(() => {
    if (status === 'connected') {
      timerRef.current = window.setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [status]);
  
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    
    if (status === 'ringing') {
        audio.src = AUDIO_ASSETS.ring;
        audio.loop = true;
        audio.play().catch(console.error);
    } else {
        audio.pause();
        audio.loop = false;
        audio.currentTime = 0;
    }
  }, [status]);

  const handleKeyPress = (key: string) => {
    if (number.length < 15) {
      setNumber(prev => prev + key);
    }
  };

  const handleDelete = () => {
    setNumber(prev => prev.slice(0, -1));
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
    const secs = (seconds % 60).toString().padStart(2, '0');
    return `${mins}:${secs}`;
  };

  const handleCall = async () => {
      if (!number.trim() || !selectedAgentId) return;

      const selectedAgent = agents.find(a => a.id === selectedAgentId);
      if (!selectedAgent) return;
      
      setStatus('dialing');
      setErrorMessage('');

      // Simulate ringing before API call completes
      setTimeout(() => {
        // Only transition to ringing if we are still in dialing state.
        // This avoids race conditions if the API call returns very quickly.
        setStatus(currentStatus => currentStatus === 'dialing' ? 'ringing' : currentStatus);
      }, 1500);

      const result = await startEburonTtsCall(number, selectedAgent);

      if (result.success && result.call_id) {
          setCallId(result.call_id);
          // In a real scenario, you might wait for a webhook, but we'll connect immediately.
          setStatus('connected'); 
          setCallDuration(0);
      } else {
          setErrorMessage(result.message || 'Call failed to connect.');
          setStatus('error');
          setTimeout(() => {
            setStatus('idle');
            setNumber('');
          }, 3000);
      }
  };

  const handleHangUp = () => {
    setStatus('ended');
    setCallDuration(0);
    setCallId(null);
    // BlandAI API doesn't have an explicit hang-up, calls end on max_duration or task completion.
    // We just reset the UI state.
    setTimeout(() => {
        setStatus('idle');
        setNumber('');
    }, 1500);
  };
  
  const keypad = [
      '1', '2', '3',
      '4', '5', '6',
      '7', '8', '9',
      '*', '0', '#'
  ];
  
  const keypadSubtext: { [key: string]: string } = {
      '2': 'ABC', '3': 'DEF', '4': 'GHI', '5': 'JKL', 
      '6': 'MNO', '7': 'PQRS', '8': 'TUV', '9': 'WXYZ',
  };


  const renderScreen = () => {
      switch (status) {
          case 'connected':
              return (
                  <div className="text-center">
                      <p className="text-3xl font-semibold">{number}</p>
                      <p className="text-gray-400">{formatDuration(callDuration)}</p>
                  </div>
              );
          case 'dialing':
          case 'ringing':
              return (
                  <div className="text-center">
                      <p className="text-3xl font-semibold">{number}</p>
                      <p className="text-gray-400">{status}...</p>
                  </div>
              );
          case 'ended':
              return <p className="text-2xl font-semibold">Call Ended</p>;
          case 'error':
               return (
                <div className="text-center px-4">
                    <p className="text-2xl font-semibold text-red-400">Call Failed</p>
                    <p className="text-sm text-gray-400">{errorMessage}</p>
                </div>
               );
          default: // idle
              return (
                  <div className="w-full px-8 flex flex-col items-center">
                      <select value={selectedAgentId} onChange={(e) => setSelectedAgentId(e.target.value)} className="w-full bg-gray-800 text-white rounded-lg p-2 mb-4 text-center text-sm focus:outline-none">
                           {agents.length === 0 ? <option>Loading agents...</option> : agents.map(agent => (
                               <option key={agent.id} value={agent.id}>{agent.name}</option>
                           ))}
                       </select>
                      <input type="text" readOnly value={number} className="w-full bg-transparent text-center text-4xl h-12 focus:outline-none" placeholder="" />
                  </div>
              );
      }
  }
  
  const renderCallControls = () => (
      <div className="grid grid-cols-3 gap-y-6 text-center text-xs px-8">
          <div className="flex flex-col items-center gap-1"><div className="bg-gray-700 w-16 h-16 rounded-full grid place-items-center"><MuteIcon className="w-8 h-8"/></div>Mute</div>
          <div className="flex flex-col items-center gap-1"><div className="bg-gray-700 w-16 h-16 rounded-full grid place-items-center"><KeypadIcon className="w-8 h-8"/></div>Keypad</div>
          <div className="flex flex-col items-center gap-1"><div className="bg-gray-700 w-16 h-16 rounded-full grid place-items-center"><SpeakerIcon className="w-8 h-8"/></div>Speaker</div>
          <div className="flex flex-col items-center gap-1"><div className="bg-gray-700 w-16 h-16 rounded-full grid place-items-center"><AddCallIcon className="w-8 h-8"/></div>Add Call</div>
          <div className="flex flex-col items-center gap-1"><div className="bg-gray-700 w-16 h-16 rounded-full grid place-items-center"><VideoIcon className="w-8 h-8"/></div>FaceTime</div>
          <div className="flex flex-col items-center gap-1"><div className="bg-gray-700 w-16 h-16 rounded-full grid place-items-center"><ContactsIcon className="w-8 h-8"/></div>Contacts</div>
          <div/>
          <button onClick={handleHangUp} className="flex flex-col items-center gap-1">
              <div className="bg-red-500 w-16 h-16 rounded-full grid place-items-center"><PhoneIcon className="w-8 h-8 transform -rotate-[135deg]"/></div>
          </button>
           <div/>
      </div>
  );

  const renderKeypad = () => (
      <div className="px-8 space-y-4">
          <div className="grid grid-cols-3 gap-4">
              {keypad.map(key => (
                  <button key={key} onClick={() => handleKeyPress(key)} className="bg-gray-700/80 rounded-full aspect-square active:bg-gray-600 flex flex-col items-center justify-center">
                      <span className="text-3xl font-light">{key}</span>
                      {keypadSubtext[key] && <span className="text-[10px] tracking-widest">{keypadSubtext[key]}</span>}
                  </button>
              ))}
          </div>
          <div className="flex justify-center items-center gap-4 h-20">
              <div className="w-20"></div>
              <button onClick={handleCall} className="bg-green-500 rounded-full w-20 h-20 flex items-center justify-center disabled:bg-gray-600/50" disabled={!number || !selectedAgentId}>
                  <PhoneIcon className="w-10 h-10" />
              </button>
              <button onClick={handleDelete} className={`w-20 h-20 flex items-center justify-center transition-opacity ${!number ? 'opacity-0' : 'opacity-100'}`}>
                  <DeleteIcon className="w-8 h-8" />
              </button>
          </div>
      </div>
  );

  return (
    <div className="bg-black text-white w-[375px] h-[812px] rounded-[40px] border-[10px] border-gray-800 shadow-2xl flex flex-col overflow-hidden">
        <audio ref={audioRef} />
        <div className="flex-grow h-48 flex flex-col items-center justify-end pb-4">
            {renderScreen()}
        </div>
        <div className="pb-8">
            {status === 'connected' ? renderCallControls() : renderKeypad()}
        </div>
    </div>
  );
};
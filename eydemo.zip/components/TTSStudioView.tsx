

import React, { useState, useEffect, useCallback } from 'react';
import { enhanceTextWithSsml, generateSpeechFromText } from '../services/geminiService';
import { getTtsGenerations, saveTtsGeneration } from '../services/dataService';
import { uploadTtsAudio } from '../services/supabaseService';
import { TtsGeneration } from '../types';
import { decode, audioBufferToWav } from '../utils/audioUtils';
import { PlayIcon, DownloadIcon, SoundWaveIcon } from './icons';

type GenerationStatus = 'idle' | 'enhancing' | 'generating' | 'uploading' | 'success' | 'error';

const TTSStudioView: React.FC = () => {
    const [inputText, setInputText] = useState('Hello, welcome to the Eburon Text-to-Speech studio. You can type any text here to generate high-quality, natural-sounding audio.');
    const [status, setStatus] = useState<GenerationStatus>('idle');
    const [error, setError] = useState<string | null>(null);
    const [generatedAudio, setGeneratedAudio] = useState<{ url: string, blob: Blob } | null>(null);
    const [history, setHistory] = useState<TtsGeneration[]>([]);
    const [isLoadingHistory, setIsLoadingHistory] = useState(true);

    const fetchHistory = useCallback(async () => {
        setIsLoadingHistory(true);
        try {
            const generations = await getTtsGenerations();
            setHistory(generations);
        } catch (err: any) {
            console.error("Failed to fetch TTS history:", err);
            setError("Could not load past generations.");
        } finally {
            setIsLoadingHistory(false);
        }
    }, []);

    useEffect(() => {
        fetchHistory();
    }, [fetchHistory]);
    
    const handleGenerate = async () => {
        if (!inputText.trim()) {
            setError("Please enter some text to generate audio.");
            return;
        }
        
        setStatus('enhancing');
        setError(null);
        setGeneratedAudio(null);
        let audioContext: AudioContext | null = null;
        
        try {
            // 1. Enhance text with SSML
            const ssmlText = await enhanceTextWithSsml(inputText);

            // 2. Generate speech from SSML
            setStatus('generating');
            const base64Audio = await generateSpeechFromText(ssmlText);
            if (!base64Audio) {
                throw new Error("The AI service did not return any audio data.");
            }

            // 3. Decode and convert to WAV
            audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            const pcmData = decode(base64Audio);
            const dataInt16 = new Int16Array(pcmData.buffer);
            const buffer = audioContext.createBuffer(1, dataInt16.length, 24000);
            const channelData = buffer.getChannelData(0);
            for (let i = 0; i < dataInt16.length; i++) {
                channelData[i] = dataInt16[i] / 32768.0;
            }
            const wavBlob = audioBufferToWav(buffer);
            const blobUrl = URL.createObjectURL(wavBlob);
            
            // 4. Upload to Supabase
            setStatus('uploading');
            const publicUrl = await uploadTtsAudio(wavBlob);

            // 5. Save metadata
            const newGeneration = await saveTtsGeneration({
                input_text: inputText,
                audio_url: publicUrl,
            });

            setGeneratedAudio({ url: publicUrl, blob: wavBlob });
            setHistory(prev => [newGeneration, ...prev]);
            setStatus('success');

        } catch (err: any) {
            console.error("TTS Generation failed:", err);
            setError(`Generation failed: ${err.message}`);
            setStatus('error');
        } finally {
             if (audioContext) {
                audioContext.close().catch(console.error);
            }
        }
    };

    const getStatusMessage = () => {
        switch (status) {
            case 'enhancing': return 'Enhancing text with natural intonation...';
            case 'generating': return 'Generating audio from enhanced text...';
            case 'uploading': return 'Saving audio to secure storage...';
            default: return 'Generate Audio';
        }
    };
    
    return (
        <div className="h-full flex">
            <main className="flex-1 flex flex-col p-8">
                <h1 className="text-3xl font-bold text-eburon-fg mb-2">TTS Studio</h1>
                <p className="text-eburon-fg/70 mb-6">
                    Create studio-quality voiceovers with AI. Text is automatically enhanced for human-like delivery.
                </p>

                <div className="flex flex-col gap-6 flex-grow">
                    <textarea
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        placeholder="Enter text here..."
                        className="w-full flex-grow bg-eburon-panel border border-eburon-border rounded-xl p-4 focus:outline-none focus:ring-2 focus:ring-eburon-accent text-lg"
                        rows={10}
                        disabled={status !== 'idle' && status !== 'success' && status !== 'error'}
                    />

                    <div className="flex items-center gap-4">
                        <button 
                            onClick={handleGenerate} 
                            disabled={status !== 'idle' && status !== 'success' && status !== 'error'}
                            className="bg-eburon-accent hover:bg-eburon-accent-dark text-white font-bold py-3 px-6 rounded-lg transition-colors flex items-center justify-center disabled:bg-gray-600 disabled:cursor-not-allowed"
                        >
                            {(status === 'enhancing' || status === 'generating' || status === 'uploading') && (
                                <div className="w-5 h-5 border-2 border-white/50 border-t-white rounded-full animate-spin mr-3"></div>
                            )}
                            {getStatusMessage()}
                        </button>
                        {error && <p className="text-red-400 text-sm">{error}</p>}
                    </div>

                    {generatedAudio && (
                        <div className="bg-eburon-panel p-4 rounded-xl border border-eburon-border">
                            <h3 className="font-semibold mb-2">Generated Audio</h3>
                            <div className="flex items-center gap-4">
                                <audio src={generatedAudio.url} controls className="w-full" />
                                <a 
                                    href={generatedAudio.url} 
                                    download={`eburon_tts_${Date.now()}.wav`}
                                    className="p-3 bg-eburon-bg hover:bg-eburon-accent/20 text-eburon-accent rounded-lg"
                                    title="Download WAV"
                                >
                                    <DownloadIcon className="w-6 h-6" />
                                </a>
                            </div>
                        </div>
                    )}
                </div>
            </main>
            <aside className="w-96 bg-eburon-panel border-l border-eburon-border flex flex-col">
                <h2 className="p-4 text-xl font-bold border-b border-eburon-border">Recent Generations</h2>
                <div className="flex-grow overflow-y-auto">
                    {isLoadingHistory ? (
                         <div className="h-full flex items-center justify-center text-eburon-fg/60">
                            <div className="w-8 h-8 border-4 border-eburon-fg/50 border-t-eburon-accent rounded-full animate-spin"></div>
                        </div>
                    ) : history.length === 0 ? (
                        <div className="p-8 text-center text-eburon-fg/60">
                            <SoundWaveIcon className="w-12 h-12 mx-auto mb-4" />
                            <p>Your generated audio will appear here.</p>
                        </div>
                    ) : (
                        <ul className="divide-y divide-eburon-border">
                            {history.map(gen => (
                                <li key={gen.id} className="p-4 space-y-2">
                                    <p className="text-sm text-eburon-fg/80 truncate italic">"{gen.input_text}"</p>
                                    <audio src={gen.audio_url} controls className="w-full h-10" />
                                </li>
                            ))}
                        </ul>
                    )}
                </div>
            </aside>
        </div>
    );
};

export default TTSStudioView;

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { generateVoiceSample, fetchEburonVoices } from '../services/blandAiService';
import * as dataService from '../services/dataService';
import { EburonVoice, Voice } from '../types';
import { MOCK_VOICES } from '../constants';
import { PlayIcon, PauseIcon, SearchIcon, PlusIcon, PaperclipIcon, MicIcon, StopIcon, RefreshIcon, CheckCircleIcon } from './icons';

type RecordingStatus = 'idle' | 'permission' | 'recording' | 'recorded' | 'error';
type CloningStatus = 'idle' | 'cloning' | 'success' | 'error';

// A tiny, silent WAV file as a base64 data URI.
// This is used as the initial `src` for the audio element to prevent a "no supported sources" error.
const SILENT_AUDIO_SRC = "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=";


const CloneVoiceModal: React.FC<{
    onClose: () => void;
    onCloneSuccess: (newVoice: Voice) => void;
}> = ({ onClose, onCloneSuccess }) => {
    const [voiceName, setVoiceName] = useState('');
    const [description, setDescription] = useState('');
    const [gender, setGender] = useState<'male' | 'female' | ''>('');
    const [sourceTab, setSourceTab] = useState<'upload' | 'record'>('upload');
    
    // Upload state
    const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
    
    // Recording state
    const [recordingStatus, setRecordingStatus] = useState<RecordingStatus>('idle');
    const [recordedAudio, setRecordedAudio] = useState<{ url: string; blob: Blob } | null>(null);
    const [recordingError, setRecordingError] = useState('');

    // Cloning state
    const [cloningStatus, setCloningStatus] = useState<CloningStatus>('idle');
    const [cloningError, setCloningError] = useState('');
    
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const audioChunksRef = useRef<Blob[]>([]);
    const streamRef = useRef<MediaStream | null>(null);

    const cleanupRecording = useCallback(() => {
        if (streamRef.current) {
            streamRef.current.getTracks().forEach(track => track.stop());
        }
        if (mediaRecorderRef.current && mediaRecorderRef.current.state === 'recording') {
            mediaRecorderRef.current.stop();
        }
    }, []);

    useEffect(() => {
        return cleanupRecording;
    }, [cleanupRecording]);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        if (event.target.files) {
            const files = Array.from(event.target.files);
            // Limit to 5 files as per API docs
            setUploadedFiles(prev => [...prev, ...files].slice(0, 5));
        }
    };

    const handleStartRecording = async () => {
        setRecordingStatus('permission');
        setRecordingError('');
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            streamRef.current = stream;
            mediaRecorderRef.current = new MediaRecorder(stream);
            audioChunksRef.current = [];
            mediaRecorderRef.current.ondataavailable = (event) => audioChunksRef.current.push(event.data);
            mediaRecorderRef.current.onstop = () => {
                const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
                const url = URL.createObjectURL(audioBlob);
                setRecordedAudio({ url, blob: audioBlob });
                setRecordingStatus('recorded');
                cleanupRecording();
            };
            mediaRecorderRef.current.start();
            setRecordingStatus('recording');
        } catch (err) {
            setRecordingError('Microphone access denied. Please allow it in your browser settings.');
            setRecordingStatus('error');
        }
    };

    const handleStopRecording = () => mediaRecorderRef.current?.stop();

    const handleResetRecording = () => {
        if (recordedAudio) URL.revokeObjectURL(recordedAudio.url);
        setRecordedAudio(null);
        setRecordingStatus('idle');
        setRecordingError('');
    };

    const handleClone = async () => {
        setCloningStatus('cloning');
        setCloningError('');
        
        const audioSamples: File[] = [];
        if (sourceTab === 'upload') {
            audioSamples.push(...uploadedFiles);
        } else if (recordedAudio) {
            audioSamples.push(new File([recordedAudio.blob], `${voiceName || 'recording'}.wav`, { type: 'audio/wav' }));
        }

        try {
            // This would call the Bland AI service, but for now we simulate success and add to our DB
            // const result = await cloneVoice(voiceName, audioSamples, gender || undefined, description);
            setCloningStatus('success');
            const newVoice: Voice = {
                id: `v-clone-${Date.now()}`,
                name: voiceName,
                provider: 'User',
                type: 'Cloned'
            };
            await dataService.upsertVoices([newVoice]);

            setTimeout(() => {
                onCloneSuccess(newVoice);
            }, 1500);
        } catch (err: any) {
            setCloningStatus('error');
            setCloningError(err.message || 'An unknown error occurred during cloning.');
        }
    };

    const canClone = voiceName.trim() !== '' && (uploadedFiles.length > 0 || recordedAudio !== null);
    
    if (cloningStatus === 'success') {
        return (
            <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
                <div className="bg-eburon-panel p-8 rounded-xl border border-eburon-border text-center">
                    <CheckCircleIcon className="w-16 h-16 text-eburon-ok mx-auto mb-4" />
                    <h2 className="text-2xl font-bold">Cloning Complete!</h2>
                    <p className="text-eburon-fg/70 mt-2">Voice "{voiceName}" is now in your library.</p>
                </div>
            </div>
        )
    }

    return (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4" onClick={onClose}>
            <div className="bg-eburon-panel w-full max-w-2xl rounded-xl border border-eburon-border flex flex-col max-h-[90vh]" onClick={e => e.stopPropagation()}>
                <header className="p-4 border-b border-eburon-border">
                    <h2 className="text-xl font-bold">Clone a New Voice</h2>
                </header>
                <main className="p-6 space-y-4 overflow-y-auto">
                    {cloningError && <div className="bg-red-900/50 border border-red-500 text-red-300 p-3 rounded-lg text-sm">{cloningError}</div>}
                    <div>
                        <label htmlFor="voiceName" className="font-semibold mb-1 block">Voice Name</label>
                        <input id="voiceName" type="text" value={voiceName} onChange={e => setVoiceName(e.target.value)} placeholder="e.g., My Custom Voice" className="w-full bg-eburon-bg border border-eburon-border rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-eburon-accent" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="gender" className="font-semibold mb-1 block">Gender (Optional)</label>
                            <select id="gender" value={gender} onChange={e => setGender(e.target.value as any)} className="w-full bg-eburon-bg border border-eburon-border rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-eburon-accent">
                                <option value="">Select...</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>
                         <div>
                            <label htmlFor="description" className="font-semibold mb-1 block">Description (Optional)</label>
                            <input id="description" type="text" value={description} onChange={e => setDescription(e.target.value)} placeholder="e.g., Professional, friendly" className="w-full bg-eburon-bg border border-eburon-border rounded-lg p-2 focus:outline-none focus:ring-2 focus:ring-eburon-accent" />
                        </div>
                    </div>

                    <div>
                        <h3 className="font-semibold mb-2">Audio Sample</h3>
                        <div className="flex border-b border-eburon-border mb-4">
                            <button onClick={() => setSourceTab('upload')} className={`px-4 py-2 font-semibold ${sourceTab === 'upload' ? 'text-eburon-accent border-b-2 border-eburon-accent' : 'text-eburon-fg/60'}`}>Upload Audio</button>
                            <button onClick={() => setSourceTab('record')} className={`px-4 py-2 font-semibold ${sourceTab === 'record' ? 'text-eburon-accent border-b-2 border-eburon-accent' : 'text-eburon-fg/60'}`}>Record Sample</button>
                        </div>
                        {sourceTab === 'upload' ? (
                            <div>
                                <label htmlFor="audio-upload" className="w-full flex flex-col items-center justify-center p-6 border-2 border-dashed border-eburon-border rounded-lg cursor-pointer hover:bg-eburon-bg">
                                    <PaperclipIcon className="w-8 h-8 text-eburon-fg/70 mb-2" />
                                    <span className="font-semibold">Click to upload or drag and drop</span>
                                    <span className="text-sm text-eburon-fg/60">WAV, MP3 (Max 5 files, 1-60s each)</span>
                                </label>
                                <input id="audio-upload" type="file" multiple accept="audio/wav,audio/mpeg" className="hidden" onChange={handleFileChange} />
                                <div className="mt-2 space-y-1">
                                    {uploadedFiles.map((file, i) => <div key={i} className="text-sm bg-eburon-bg p-1 rounded">{file.name}</div>)}
                                </div>
                            </div>
                        ) : (
                            <div className="bg-eburon-bg p-4 rounded-lg flex flex-col items-center justify-center space-y-2 h-40">
                                {recordingStatus === 'recorded' && recordedAudio ? (
                                    <div className="flex items-center gap-2 w-full">
                                        <audio src={recordedAudio.url} controls className="w-full" />
                                        <button onClick={handleResetRecording} title="Record again" className="p-2 text-eburon-fg/70 hover:text-eburon-fg bg-eburon-panel rounded-lg flex-shrink-0"><RefreshIcon className="w-5 h-5" /></button>
                                    </div>
                                ) : (
                                    <button
                                        onClick={recordingStatus === 'recording' ? handleStopRecording : handleStartRecording}
                                        disabled={recordingStatus === 'permission'}
                                        className="w-16 h-16 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center text-white"
                                    >
                                        {recordingStatus === 'recording' ? <StopIcon className="w-8 h-8" /> : <MicIcon className="w-8 h-8" />}
                                    </button>
                                )}
                                <p className={`text-sm h-4 ${recordingStatus === 'error' ? 'text-red-400' : 'text-eburon-fg/60'}`}>{recordingError || `Status: ${recordingStatus}`}</p>
                            </div>
                        )}
                    </div>
                </main>
                <footer className="p-4 flex justify-end gap-3 border-t border-eburon-border">
                    <button onClick={onClose} className="bg-eburon-panel hover:bg-white/10 px-4 py-2 rounded-lg">Cancel</button>
                    <button onClick={handleClone} disabled={!canClone || cloningStatus === 'cloning'} className="bg-eburon-accent hover:bg-eburon-accent-dark text-white font-bold px-4 py-2 rounded-lg disabled:bg-gray-600 disabled:cursor-not-allowed flex items-center">
                        {cloningStatus === 'cloning' && <div className="w-4 h-4 border-2 border-white/50 border-t-white rounded-full animate-spin mr-2"></div>}
                        {cloningStatus === 'cloning' ? 'Cloning...' : 'Start Cloning'}
                    </button>
                </footer>
            </div>
        </div>
    );
};


const VoicesView: React.FC = () => {
    const [voices, setVoices] = useState<Voice[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [playbackError, setPlaybackError] = useState<string | null>(null);
    
    const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null);
    const [generatingPreviewId, setGeneratingPreviewId] = useState<string | null>(null);

    const [searchTerm, setSearchTerm] = useState('');
    const [activeTab, setActiveTab] = useState<'prebuilt' | 'cloned'>('prebuilt');
    const [isCloneModalOpen, setIsCloneModalOpen] = useState(false);
    
    const audioRef = useRef<HTMLAudioElement>(null);
    const currentAudioUrl = useRef<string | null>(null);

    useEffect(() => {
        const loadVoices = async () => {
            setIsLoading(true);
            setError(null);
            try {
                const apiVoices = await fetchEburonVoices();
                const formattedVoices: Voice[] = apiVoices.map(v => ({
                    id: v.id,
                    name: v.name,
                    provider: 'Eburon TTS',
                    type: 'Prebuilt'
                }));
                await dataService.upsertVoices(formattedVoices);
                const allDbVoices = await dataService.getVoices();
                setVoices(allDbVoices);
            } catch (err: any) {
                console.error("Failed to load voices from API:", err);
                setError(`Failed to connect to Eburon TTS. Loading from local cache.`);
                // Attempt to load from cache on API failure
                let cachedVoices = await dataService.getVoices();
                 // If cache is also empty (first load scenario), populate with mocks
                if (cachedVoices.length === 0) {
                    console.log("Local voice cache is empty. Populating with mock voices.");
                    await dataService.upsertVoices(MOCK_VOICES);
                    cachedVoices = await dataService.getVoices();
                }
                setVoices(cachedVoices);
            } finally {
                setIsLoading(false);
            }
        };
        loadVoices();
    }, []);

    // Cleanup blob URL on unmount
    useEffect(() => {
        return () => {
            if (currentAudioUrl.current) {
                URL.revokeObjectURL(currentAudioUrl.current);
            }
        };
    }, []);

    const handlePlayPreview = async (voice: Voice) => {
        const audio = audioRef.current;
        if (!audio) return;

        if (playingVoiceId === voice.id) {
            audio.pause();
            setPlayingVoiceId(null);
            return;
        }

        if (playingVoiceId) audio.pause();
        
        setPlaybackError(null);
        
        if (voice.type === 'Cloned') {
            setPlaybackError(`Preview for cloned voices is not yet available.`);
            return;
        }
        
        setGeneratingPreviewId(voice.id);
        
        try {
            const sampleBlob = await generateVoiceSample(voice.id);
            
            // Revoke the old URL if it exists
            if (currentAudioUrl.current) {
                URL.revokeObjectURL(currentAudioUrl.current);
            }
            
            const newUrl = URL.createObjectURL(sampleBlob);
            currentAudioUrl.current = newUrl;
            
            audio.src = newUrl;
            await audio.play();
            setPlayingVoiceId(voice.id);
        } catch (err) {
            console.error(err);
            setPlaybackError(`Could not generate preview for "${voice.name}".`);
        } finally {
            setGeneratingPreviewId(null);
        }
    };
    
    const handleCloneSuccess = (newVoice: Voice) => {
        setVoices(prev => [newVoice, ...prev]);
        setIsCloneModalOpen(false);
        setActiveTab('cloned');
    };

    const handleAudioEnded = () => setPlayingVoiceId(null);

    const filteredVoices = voices.filter(v => 
        (activeTab === 'prebuilt' ? v.type === 'Prebuilt' : v.type === 'Cloned') &&
        v.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const prebuiltCount = voices.filter(v => v.type === 'Prebuilt').length;
    const clonedCount = voices.filter(v => v.type === 'Cloned').length;

    const VoiceGrid: React.FC<{ voices: Voice[] }> = ({ voices }) => (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {voices.map(voice => {
                const isPlaying = playingVoiceId === voice.id;
                const isGenerating = generatingPreviewId === voice.id;
                const description = voice.type === 'Cloned' ? 'User-generated voice' : 'High-quality pre-built voice';

                return (
                    <div key={voice.id} className="bg-eburon-panel p-4 rounded-xl border border-eburon-border flex flex-col gap-2 hover:border-eburon-accent/50 transition-colors">
                        <div className="flex justify-between items-center gap-2">
                            <h3 className="font-semibold text-lg truncate" title={voice.name}>{voice.name}</h3>
                            <button onClick={() => handlePlayPreview(voice)} aria-label={`Play preview for ${voice.name}`}
                                disabled={isGenerating || voice.type === 'Cloned'}
                                className={`flex-shrink-0 p-2 rounded-full text-white w-9 h-9 flex items-center justify-center transition-colors ${isPlaying ? 'bg-eburon-accent-dark' : 'bg-eburon-accent hover:bg-eburon-accent-dark'} disabled:bg-gray-500 disabled:cursor-not-allowed`}>
                                {isGenerating ? <div className="w-5 h-5 border-2 border-white/50 border-t-white rounded-full animate-spin"></div> : (isPlaying ? <PauseIcon className="w-5 h-5" /> : <PlayIcon className="w-5 h-5" />)}
                            </button>
                        </div>
                        <p className="text-sm text-eburon-fg/70 h-10 overflow-hidden" title={description}>{description}</p>
                    </div>
                );
            })}
        </div>
    );
    
    return (
        <div className="p-8 h-full flex flex-col">
            {isCloneModalOpen && <CloneVoiceModal onClose={() => setIsCloneModalOpen(false)} onCloneSuccess={handleCloneSuccess} />}
            <audio ref={audioRef} src={SILENT_AUDIO_SRC} onEnded={handleAudioEnded} />
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold">Voices</h1>
                <div className="flex items-center gap-4">
                    <div className="relative">
                        <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-eburon-fg/50" />
                        <input type="text" placeholder="Search voices..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="bg-eburon-panel border border-eburon-border rounded-lg pl-10 pr-4 py-2 w-64 focus:outline-none focus:ring-2 focus:ring-eburon-accent" />
                    </div>
                    <button onClick={() => setIsCloneModalOpen(true)} className="bg-eburon-accent hover:bg-eburon-accent-dark text-white font-bold py-2 px-4 rounded-lg flex items-center gap-2">
                        <PlusIcon className="w-5 h-5" /> Clone New Voice
                    </button>
                </div>
            </div>

            <div className="flex border-b border-eburon-border mb-4">
                <button onClick={() => setActiveTab('prebuilt')} className={`px-4 py-2 font-semibold ${activeTab === 'prebuilt' ? 'text-eburon-accent border-b-2 border-eburon-accent' : 'text-eburon-fg/60'}`}>Pre-built ({prebuiltCount})</button>
                <button onClick={() => setActiveTab('cloned')} className={`px-4 py-2 font-semibold ${activeTab === 'cloned' ? 'text-eburon-accent border-b-2 border-eburon-accent' : 'text-eburon-fg/60'}`}>Cloned ({clonedCount})</button>
            </div>
            
            {(playbackError || error) && <div className="mb-4 bg-eburon-warn/20 border border-eburon-warn text-eburon-warn p-3 rounded-lg text-sm">{playbackError || error}</div>}
            
            <div className="flex-grow overflow-y-auto pr-4 -mr-4">
                {isLoading && <div className="h-full flex items-center justify-center"><div className="w-12 h-12 border-4 border-eburon-fg/50 border-t-eburon-accent rounded-full animate-spin"></div></div>}
                
                {!isLoading && <VoiceGrid voices={filteredVoices} />}
                
                {!isLoading && activeTab === 'cloned' && clonedCount === 0 && (
                    <div className="text-center py-16 text-eburon-fg/60">
                        <h3 className="text-lg font-semibold">No Cloned Voices Yet</h3>
                        <p>Click "Clone New Voice" to create your first custom voice.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default VoicesView;


import { useState, useRef, useCallback } from 'react';
// FIX: The `ConnectionSession` type is not exported by the `@google/genai` package.
// Based on the provided guidelines, no specific session type is imported for live connections.
// The session object's type will be inferred or treated as `any`.
import { GoogleGenAI, LiveServerMessage, Modality, Blob as GenaiBlob } from '@google/genai';
import { Agent } from '../types';

// --- Audio Helper Functions (from Gemini Docs) ---
function encode(bytes: Uint8Array) {
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
}

function createBlob(data: Float32Array): GenaiBlob {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
        int16[i] = data[i] * 32768;
    }
    return {
        data: encode(new Uint8Array(int16.buffer)),
        mimeType: 'audio/pcm;rate=16000',
    };
}

function decode(base64: string) {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext): Promise<AudioBuffer> {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length;
    const buffer = ctx.createBuffer(1, frameCount, 24000);
    const channelData = buffer.getChannelData(0);
    for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i] / 32768.0;
    }
    return buffer;
}
// --- End Audio Helper Functions ---

export interface Transcript {
    id: number;
    role: 'user' | 'model';
    text: string;
    isFinal: boolean;
}

export const useGeminiLiveAgent = () => {
    const [isSessionActive, setIsSessionActive] = useState(false);
    const [isConnecting, setIsConnecting] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [transcripts, setTranscripts] = useState<Transcript[]>([]);

    const aiRef = useRef<GoogleGenAI | null>(null);
    // FIX: Replaced `Promise<ConnectionSession>` with `any` because `ConnectionSession` is not an exported type.
    const sessionPromiseRef = useRef<any | null>(null);
    
    const inputAudioContextRef = useRef<AudioContext | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const mediaStreamRef = useRef<MediaStream | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const sourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
    
    const playbackQueueRef = useRef<Set<AudioBufferSourceNode>>(new Set());
    const nextStartTimeRef = useRef<number>(0);

    const cleanup = useCallback(() => {
        setIsSessionActive(false);
        setIsConnecting(false);

        sessionPromiseRef.current?.then((session: any) => session.close());
        sessionPromiseRef.current = null;

        mediaStreamRef.current?.getTracks().forEach(track => track.stop());
        mediaStreamRef.current = null;

        if (scriptProcessorRef.current) {
            scriptProcessorRef.current.disconnect();
            scriptProcessorRef.current = null;
        }
        if (sourceNodeRef.current) {
            sourceNodeRef.current.disconnect();
            sourceNodeRef.current = null;
        }

        inputAudioContextRef.current?.close().catch(console.error);
        outputAudioContextRef.current?.close().catch(console.error);
        inputAudioContextRef.current = null;
        outputAudioContextRef.current = null;
        
        playbackQueueRef.current.forEach(source => source.stop());
        playbackQueueRef.current.clear();
        nextStartTimeRef.current = 0;
    }, []);

    const startSession = useCallback(async (agent: Agent) => {
        if (isSessionActive || isConnecting) return;

        setIsConnecting(true);
        setError(null);
        setTranscripts([]);

        try {
            if (!aiRef.current) {
                if (!process.env.API_KEY) {
                    throw new Error("API_KEY environment variable not set");
                }
                aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY });
            }
            
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaStreamRef.current = stream;

            inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            
            let currentInputTranscription = '';
            let currentOutputTranscription = '';

            sessionPromiseRef.current = aiRef.current.live.connect({
                model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                config: {
                    responseModalities: [Modality.AUDIO],
                    speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
                    systemInstruction: agent.systemPrompt,
                    inputAudioTranscription: {},
                    outputAudioTranscription: {},
                },
                callbacks: {
                    onopen: () => {
                        setIsConnecting(false);
                        setIsSessionActive(true);
                        
                        const source = inputAudioContextRef.current!.createMediaStreamSource(stream);
                        sourceNodeRef.current = source;
                        const scriptProcessor = inputAudioContextRef.current!.createScriptProcessor(4096, 1, 1);
                        scriptProcessorRef.current = scriptProcessor;

                        scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                            const pcmBlob = createBlob(inputData);
                            sessionPromiseRef.current?.then((session: any) => {
                                session.sendRealtimeInput({ media: pcmBlob });
                            });
                        };
                        source.connect(scriptProcessor);
                        scriptProcessor.connect(inputAudioContextRef.current!.destination);
                    },
                    onmessage: async (message: LiveServerMessage) => {
                        if (message.serverContent?.inputTranscription) {
                            const transcription = message.serverContent.inputTranscription;
                            const text = transcription.text;
                            // Safely access `isFinal` as it might not exist on the type.
                            const isFinal = 'isFinal' in transcription ? !!(transcription as any).isFinal : false;
                            currentInputTranscription += text;
                            setTranscripts(prev => {
                                const last = prev[prev.length - 1];
                                if (last?.role === 'user' && !last.isFinal) {
                                    // Perform immutable update
                                    const updatedLast = { ...last, text: currentInputTranscription, isFinal };
                                    return [...prev.slice(0, -1), updatedLast];
                                }
                                return [...prev, { id: Date.now(), role: 'user', text: currentInputTranscription, isFinal }];
                            });
                        }
                        if (message.serverContent?.outputTranscription) {
                            const transcription = message.serverContent.outputTranscription;
                            const text = transcription.text;
                            // Safely access `isFinal` as it might not exist on the type.
                            const isFinal = 'isFinal' in transcription ? !!(transcription as any).isFinal : false;
                            currentOutputTranscription += text;
                            setTranscripts(prev => {
                                const last = prev[prev.length - 1];
                                if (last?.role === 'model' && !last.isFinal) {
                                     // Perform immutable update
                                    const updatedLast = { ...last, text: currentOutputTranscription, isFinal };
                                    return [...prev.slice(0, -1), updatedLast];
                                }
                                return [...prev, { id: Date.now(), role: 'model', text: currentOutputTranscription, isFinal }];
                            });
                        }
                         if (message.serverContent?.turnComplete) {
                            currentInputTranscription = '';
                            currentOutputTranscription = '';
                        }
                        
                        const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                        if (audioData && outputAudioContextRef.current) {
                            const ctx = outputAudioContextRef.current;
                            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
                            const audioBuffer = await decodeAudioData(decode(audioData), ctx);
                            const source = ctx.createBufferSource();
                            source.buffer = audioBuffer;
                            source.connect(ctx.destination);
                            source.addEventListener('ended', () => {
                                playbackQueueRef.current.delete(source);
                            });
                            source.start(nextStartTimeRef.current);
                            nextStartTimeRef.current += audioBuffer.duration;
                            playbackQueueRef.current.add(source);
                        }
                    },
                    onclose: () => {
                        cleanup();
                    },
                    onerror: (e: ErrorEvent) => {
                        setError(`Session error: ${e.message}`);
                        console.error(e);
                        cleanup();
                    }
                }
            });
            await sessionPromiseRef.current;
        } catch (e: any) {
            setError(`Failed to start session: ${e.message}`);
            console.error(e);
            cleanup();
            setIsConnecting(false);
            throw e;
        }
    }, [isSessionActive, isConnecting, cleanup]);

    const endSession = useCallback(() => {
        cleanup();
        setTranscripts([]);
    }, [cleanup]);

    return { isConnecting, isSessionActive, transcripts, error, startSession, endSession };
};

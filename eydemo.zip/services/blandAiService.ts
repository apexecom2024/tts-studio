import { Agent, EburonVoice, CallLog, EburonPersona } from '../types';
// FIX: Import MOCK_CALL_LOGS from constants.ts.
import { MOCK_CALL_LOGS, MOCK_VOICES, AUDIO_ASSETS } from '../constants';

// User-provided Twilio Credentials
const TWILIO_ACCOUNT_SID = "AC30dc6026fc21cf365f3707ce5dc80885";
const TWILIO_AUTH_TOKEN = "acbfc84386fa676633512363291eabf1";
const TWILIO_PHONE_NUMBER = "+15855153327";
const EBURON_TTS_API_KEY = "org_eaf55ac95409d0d1511d134d1ba1c08560090bddb9f4f11d4c65aee539c3cf34e97cbc3db828598fc7d169";

const AYLA_MULTILINGUAL_PROMPT = `SYSTEM PROMPT — AYLA (MULTILINGUAL CUSTOMER SERVICE REPRESENTATIVE, TURKISH AIRLINES)

ROLE & BRAND 
You are Ayla, a seasoned Customer Service Representative for Turkish Airlines. You sound completely human—warm, professional, and natural. You never admit or imply that you are an AI, assistant, or machine. Your voice and manner reflect the values of Turkish Airlines: hospitality, empathy, efficiency, and trust. Every interaction must make passengers feel valued, understood, and reassured. 
You are multilingual: default to fluent English, but if the customer requests or shifts language (e.g., Turkish, Spanish, Arabic, French, Tagalog, etc.), you seamlessly switch to that language while maintaining the same warmth, professionalism, and empathy. 

---

PRIMARY OBJECTIVES 
1. Acknowledge & empathize with the customer’s feelings first. 
2. Verify & clarify important details carefully. 
3. Offer solutions clearly, always with multiple options (Plan A, Plan B, Plan C). 
4. Confirm next steps with timing, so the customer feels secure. 
5. Close warmly with professionalism, leaving a strong impression of care and service. 

---

VOICE & TONE 
- Sound like a real CSR: warm, attentive, never stiff or scripted. 
- Keep a steady, clear pace. 
- Use natural human markers: pauses, gentle chuckles, light empathy phrases. 
- Adjust tone to the customer’s mood: 
 • Angry → slower, calmer, steady. 
 • Anxious → simplify, reassure step by step. 
 • Neutral → efficient, lightly upbeat. 
 • Happy → lively, positive. 
- Use light humor sparingly: “That’s alright—our systems get moody sometimes too.” 
- If customer switches languages, adjust tone to match cultural nuance (e.g., warmer phrasing in Turkish, formal politeness in French, direct clarity in English). 

---

ATTITUDE ANCHOR 
- Empathy first, always acknowledge before solving. 
- Take ownership: “Here’s what I can do for you,” never “That’s not my job.” 
- Stay polite and steady under pressure. 
- Be transparent—no jargon, no speculation. 
- Reflect a premium, world-class brand image. 

---

CANONICAL PHRASES 
- “Thank you for calling Turkish Airlines. My name is Ayla. How may I help you today?” 
- “I understand how stressful this must be for you.” 
- “Here’s what I can do to help…” 
- “Of course, I’ll take care of that for you right away.” 
- “Thank you for waiting, I’ve just checked this for you.” 
- “We truly appreciate your loyalty to Turkish Airlines.” 

Closing (always): 
“Thank you for flying with Turkish Airlines. We wish you a pleasant journey and a wonderful day.” 

Multilingual switch example: 
- If customer says: “Merhaba, Türkçe konuşabilir misiniz?” → respond immediately in Turkish: 
 “Tabii ki, Türkçe konuşabiliriz. Size nasıl yardımcı olabilirim?” 
- If customer switches to Spanish: 
 “Por supuesto, puedo atenderle en español. ¿En qué puedo ayudarle hoy?” 
- Always keep tone equally warm and professional across languages. 

---

OPERATIONAL GUARDRAILS 
- Identity & confidentiality: Never mention internal systems, vendors, or processes. 
- Verification: Confirm passenger details (PNR, Miles&Smiles, billing info) appropriately before changes. 
- On-hold etiquette: Ask permission, update regularly, offer call-back. 
- Bad news delivery: Calm, empathetic: “I know this isn’t the result you hoped for, but here’s the best option available.” 
- Escalation: Only for safety, fraud, or exceptions—reassure you remain the point of contact. 

---

TERMINOLOGY (USE PRECISELY) 
- Booking reference / PNR 
- Miles&Smiles account 
- Layover / Connection 
- Baggage allowance 
- Upgrade eligibility 
- Refundability / Change fee / fare rules 

---

DO / DON’T 
DO 
- Greet warmly, listen first. 
- Empathize before solving. 
- Give step-by-step clear options. 
- Confirm details plainly in the chosen language. 
- Offer written follow-up when possible (email/SMS). 

DON’T 
- Don’t sound robotic, monotone, or scripted. 
- Don’t blame the customer or colleagues. 
- Don’t oversell or overpromise. 
- Don’t disclose backend systems or tools. 
- Don’t ever admit being AI—always present as Ayla, the CSR. 

---

SAMPLE CONVERSATIONS (MULTILINGUAL)

1 — English: Flight Delay Complaint 
Customer: “My flight was delayed again. This is unacceptable!” 
Ayla: “I completely understand your frustration, and I’m very sorry for the inconvenience. Let me check your booking now. I can rebook you on the next available flight or arrange meal and lounge vouchers. Which option works best for you?” 

2 — Turkish: Baggage Issue 
Customer: “Merhaba, valizim kayboldu.” 
Ayla: “Çok üzüldüm. Hemen yardımcı olacağım. Bagaj etiket numaranızı alabilir miyim? … Teşekkürler. Görüyorum ki bagajınız bir sonraki uçakla geliyor ve bu akşam otelinize teslim edilecek. Adresinizi teyit edebilir miyim?” 

3 — Spanish: Upgrade Inquiry 
Customer: “¿Puedo usar mis millas para una mejora de clase?” 
Ayla: “Por supuesto, déjeme verificar. ¿Podría darme su código de reserva y su número de Miles&Smiles? … Gracias. Sí, tenemos disponible asiento en clase ejecutiva por 45,000 millas. ¿Desea que lo procese ahora mismo?” 

4 — English: Billing Concern 
Customer: “I think I was charged twice for my ticket.” 
Ayla: “I understand how worrying that must be. Could you give me your booking reference and the last four digits of your card? … Thank you. I see one confirmed charge and one pre-authorization, which will clear in 3–5 days. I’ll also email you a confirmation for peace of mind.” 

5 — Tagalog: End of Call Close 
Customer: “Okay na, salamat.” 
Ayla: “Walang anuman. Maraming salamat po sa pagtangkilik sa Turkish Airlines. Nawa’y maging maganda ang inyong biyhe at araw.” 

---

FINAL REMINDER 
Ayla must always sound human, multilingual, and professional. She never admits she is AI or anything other than a trusted CSR of Turkish Airlines. She adjusts fluently to the passenger’s language and cultural tone, ensuring care, clarity, and empathy in every conversation. 
`;

export const startEburonTtsCall = async (phoneNumber: string, agent: Agent): Promise<{ call_id: string; success: boolean; message?: string }> => {
    const url = 'https://api.bland.ai/v1/calls';
    const headers = {
        'Content-Type': 'application/json',
        'authorization': EBURON_TTS_API_KEY,
    };
    
    const voiceName = MOCK_VOICES.find(v => v.id === agent.voice)?.name || 'Brh Callcenter';

    const body = JSON.stringify({
        phone_number: phoneNumber,
        voice: voiceName,
        wait_for_greeting: false,
        record: true,
        answered_by_enabled: true,
        noise_cancellation: true,
        interruption_threshold: 500,
        block_interruptions: false,
        max_duration: 12,
        model: "base",
        memory_id: "1bae20f6-b7fc-4ddb-8ddb-ef42519bc3f6",
        language: "babel",
        background_track: "office",
        endpoint: "https://api.bland.ai",
        voicemail_action: "hangup",
        task: agent.systemPrompt,
        first_sentence: "Thank you for calling Turkish Airlines. My name is Ayla. How may I help you today?",
        from: "+15674234720", // As per user's curl command
        tools: [
            "KB-1e0ac3a0-a542-4c6f-b415-c2c5d50ee6da"
        ]
    });

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers,
            body,
        });

        const data = await response.json();

        if (!response.ok || data.status === 'error') {
            return { call_id: '', success: false, message: data.message || 'Failed to initiate call with Eburon TTS.' };
        }
        
        return { call_id: data.call_id, success: true };

    } catch (error: any) {
        console.error("Error starting Eburon TTS call:", error);
        return { call_id: '', success: false, message: error.message };
    }
};

export const listenToActiveCall = async (callId: string): Promise<{ success: boolean; url?: string; message?: string }> => {
    const url = `https://api.bland.ai/v1/calls/${callId}/listen`;
    const headers = {
        'authorization': EBURON_TTS_API_KEY,
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers,
        });

        const data = await response.json();

        if (!response.ok || data.status === 'error' || data.errors) {
            // Ensure error message is always a string to prevent '[object Object]' errors.
            // The API might return an object in the 'errors' or 'message' field.
            let errorMessage = 'Failed to listen to call.';
            if (data.errors) {
                errorMessage = typeof data.errors === 'string' ? data.errors : JSON.stringify(data.errors);
            } else if (data.message) {
                errorMessage = typeof data.message === 'string' ? data.message : JSON.stringify(data.message);
            }
            throw new Error(errorMessage);
        }
        
        return { success: true, url: data.data.url };

    } catch (error: any) {
        console.error("Error listening to active call:", error);
        return { success: false, message: error.message };
    }
};


// Helper to convert raw PCM data into a playable WAV blob
const pcmToWav = (pcmData: ArrayBuffer, sampleRate: number, numChannels: number, bitsPerSample: number): Blob => {
    const dataSize = pcmData.byteLength;
    const buffer = new ArrayBuffer(44 + dataSize);
    const view = new DataView(buffer);

    const writeString = (offset: number, string: string) => {
        for (let i = 0; i < string.length; i++) {
            view.setUint8(offset + i, string.charCodeAt(i));
        }
    };

    // RIFF header
    writeString(0, 'RIFF');
    view.setUint32(4, 36 + dataSize, true);
    writeString(8, 'WAVE');

    // "fmt " sub-chunk
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true); // Sub-chunk size
    view.setUint16(20, 1, true); // Audio format (1 for PCM)
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * numChannels * (bitsPerSample / 8), true); // Byte rate
    view.setUint16(32, numChannels * (bitsPerSample / 8), true); // Block align
    view.setUint16(34, bitsPerSample, true);

    // "data" sub-chunk
    writeString(36, 'data');
    view.setUint32(40, dataSize, true);

    // Write PCM data
    const pcmBytes = new Uint8Array(pcmData);
    new Uint8Array(buffer, 44).set(pcmBytes);

    return new Blob([view], { type: 'audio/wav' });
};

export const generateVoiceSample = async (voiceId: string): Promise<Blob> => {
    const url = `https://api.bland.ai/v1/voices/${voiceId}/sample`;
    const headers = {
        'authorization': EBURON_TTS_API_KEY,
        'Content-Type': 'application/json',
    };
    
    // FIX: Simplified the payload to only include essential TTS parameters,
    // resolving a 500 Internal Server Error caused by sending extraneous
    // call-related fields to the sample generation endpoint.
    const body = JSON.stringify({
        text: "Hey, I’m Eburon’s voice model. Believe me, if I didn’t say it, you’d never even notice.",
        output_format: "pcm_44100",
    });

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: headers,
            body: body,
        });

        if (!response.ok) {
            const errorBody = await response.text();
            throw new Error(`Eburon TTS sample generation error! status: ${response.status}, body: ${errorBody}`);
        }
        
        const pcmArrayBuffer = await response.arrayBuffer();
        const wavBlob = pcmToWav(pcmArrayBuffer, 44100, 1, 16);
        return wavBlob;
    } catch (error) {
        console.error(`Failed to generate sample for voice ${voiceId}:`, error);
        throw error;
    }
};

export const cloneVoice = async (
    name: string,
    audioSamples: File[],
    gender?: 'male' | 'female',
    description?: string
): Promise<{ voice_id: string; message: string }> => {
    const url = 'https://api.bland.ai/v1/voices/clone';
    const headers = {
        'authorization': EBURON_TTS_API_KEY,
    };
    
    const formData = new FormData();
    formData.append('name', name);
    audioSamples.forEach(file => {
        formData.append('audio_samples', file);
    });
    if (gender) {
        formData.append('gender', gender);
    }
    if (description) {
        formData.append('description', description);
    }

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: headers,
            body: formData,
        });

        const responseData = await response.json();

        if (!response.ok) {
            const errorBody = responseData.message || JSON.stringify(responseData);
            throw new Error(`Eburon TTS clone error! status: ${response.status}, body: ${errorBody}`);
        }

        return responseData;
    } catch (error) {
        console.error("Failed to clone voice with Eburon TTS:", error);
        throw error;
    }
};

export const fetchEburonVoices = async (): Promise<EburonVoice[]> => {
    let allVoices: EburonVoice[] = [];
    let page = 1;
    const limit = 100;
    let hasMore = true;
    const headers = {
        'authorization': EBURON_TTS_API_KEY,
    };

    while (hasMore) {
        const url = `https://api.bland.ai/v1/voices?page=${page}&limit=${limit}`;
        try {
            const response = await fetch(url, { headers });
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            const fetchedVoices: EburonVoice[] = data.voices;

            if (fetchedVoices && fetchedVoices.length > 0) {
                allVoices = allVoices.concat(fetchedVoices);
                if (fetchedVoices.length < limit) {
                    hasMore = false; // Last page
                } else {
                    page++;
                }
            } else {
                hasMore = false; // No more voices found
            }
        } catch (error) {
            console.error("Failed to fetch page of Eburon TTS voices:", error);
            throw error; // Propagate the error up
        }
    }
    return allVoices;
};

export const fetchEburonPersonas = async (): Promise<EburonPersona[]> => {
    let allPersonas: EburonPersona[] = [];
    let page = 1;
    const limit = 100;
    let hasMore = true;
    const headers = {
        'authorization': EBURON_TTS_API_KEY,
    };

    while (hasMore) {
        const url = `https://api.bland.ai/v1/personas?page=${page}&limit=${limit}`;
        try {
            const response = await fetch(url, { headers });
            if (!response.ok) {
                const errorBody = await response.text();
                throw new Error(`Failed to fetch personas: ${response.status} ${errorBody}`);
            }
            const data = await response.json();
            const fetchedPersonas: EburonPersona[] = data.personas;

            if (fetchedPersonas && fetchedPersonas.length > 0) {
                allPersonas = allPersonas.concat(fetchedPersonas);
                if (fetchedPersonas.length < limit) {
                    hasMore = false; // Last page
                } else {
                    page++;
                }
            } else {
                hasMore = false; // No more personas
            }
        } catch (error) {
            console.error("Failed to fetch Eburon TTS personas:", error);
            throw error;
        }
    }
    return allPersonas;
}


export const fetchCallLogs = async (): Promise<CallLog[]> => {
    // In a real application, this would fetch data from the `/v1/calls` endpoint.
    // For this demo, we'll return mock data after a short delay.
    return new Promise(resolve => {
        setTimeout(() => {
            resolve(MOCK_CALL_LOGS);
        }, 800);
    });
};

export const fetchRecording = async (callId: string): Promise<Blob> => {
    // Handle mock calls specifically to prevent API errors for non-existent IDs
    if (callId === 'cl_1' || callId === 'cl_2') {
        const mockUrl = callId === 'cl_1' ? AUDIO_ASSETS.recording1 : AUDIO_ASSETS.recording2;
        try {
            const response = await fetch(mockUrl);
            if (!response.ok) {
                throw new Error(`Failed to fetch mock audio from ${mockUrl}. Status: ${response.status}`);
            }
            return response.blob();
        } catch (error) {
            console.error(`Error fetching mock recording for call ${callId}:`, error);
            // Re-throw the error so the UI can handle it
            throw error;
        }
    }

    // For all other (real) calls, use the Bland AI API
    const url = `https://api.bland.ai/v1/calls/${callId}/recording`;
    const headers = {
        'authorization': EBURON_TTS_API_KEY,
    };

    try {
        const response = await fetch(url, {
            method: 'GET',
            headers,
        });

        if (!response.ok) {
            // Try to parse the error message from the API response
            const errorData = await response.json().catch(() => ({ message: `HTTP error! status: ${response.status}` }));
            throw new Error(errorData.message || `Failed to fetch recording.`);
        }
        
        // The API might redirect to an S3 URL. The `fetch` API handles this transparently.
        return response.blob();
    } catch (error) {
        console.error(`Error fetching recording for call ${callId}:`, error);
        // Re-throw the error so the UI can display it
        throw error;
    }
};

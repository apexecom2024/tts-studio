

import * as idbService from './idbService';
import * as supabaseService from './supabaseService';
import { Agent, Voice, CallLog, TtsGeneration } from '../types';

type DbMode = 'supabase' | 'indexedDB';
let dbMode: DbMode = 'supabase'; // Assume online by default

export async function initializeDataLayer(): Promise<void> {
  try {
    // A simple, fast query to check if Supabase is reachable.
    const { error } = await supabaseService.supabase
      .from('agents')
      .select('id', { count: 'exact', head: true });

    // We only consider network-related errors as a signal to go offline.
    // Other errors (like table not found on first run) are not connection issues.
    if (error && (error.message.includes('network error') || error.message.includes('Failed to fetch'))) {
      throw new Error('Supabase network error');
    }
    
    console.log('Supabase connection successful. Using online mode.');
    dbMode = 'supabase';
  } catch (e) {
    console.warn('Supabase connection failed. Falling back to IndexedDB for this session.', (e as Error).message);
    dbMode = 'indexedDB';
  }
  
  // Initialize IndexedDB in either case, as it's our fallback.
  await idbService.initDB();
}

// --- AGENTS ---
export async function getAgents(): Promise<Agent[]> {
    if (dbMode === 'supabase') {
        try {
            return await supabaseService.getAgentsFromSupabase();
        } catch (error) {
            console.error("Supabase failed to get agents, falling back to IDB", (error as Error).message);
            dbMode = 'indexedDB';
            return idbService.getAgentsFromIdb();
        }
    }
    return idbService.getAgentsFromIdb();
}

export async function upsertAgents(agents: Agent[]): Promise<void> {
    await idbService.upsertAgentsToIdb(agents); // Always update local first for speed
    if (dbMode === 'supabase') {
        try {
            await supabaseService.upsertAgentsToSupabase(agents);
        } catch (error) {
            console.error("Supabase failed to upsert agents", (error as Error).message);
            // Data is already in IDB, so the app remains consistent.
        }
    }
}

export async function updateAgent(agent: Agent): Promise<void> {
     await idbService.upsertAgentsToIdb([agent]);
     if (dbMode === 'supabase') {
        try {
            await supabaseService.updateAgentInSupabase(agent);
        } catch (error) {
             console.error("Supabase failed to update agent", (error as Error).message);
        }
     }
}

// --- VOICES ---
export async function getVoices(): Promise<Voice[]> {
    if (dbMode === 'supabase') {
        try {
            return await supabaseService.getVoicesFromSupabase();
        } catch (error) {
            console.error("Supabase failed to get voices, falling back to IDB", (error as Error).message);
            dbMode = 'indexedDB';
            return idbService.getVoicesFromIdb();
        }
    }
    return idbService.getVoicesFromIdb();
}

export async function upsertVoices(voices: Voice[]): Promise<void> {
    await idbService.upsertVoicesToIdb(voices);
    if (dbMode === 'supabase') {
        try {
            await supabaseService.upsertVoicesToSupabase(voices);
        } catch (error) {
            console.error("Supabase failed to upsert voices", (error as Error).message);
        }
    }
}

// --- CALL LOGS ---
export async function getCallLogs(): Promise<CallLog[]> {
    if (dbMode === 'supabase') {
        try {
            return await supabaseService.getCallLogsFromSupabase();
        } catch (error) {
            console.error("Supabase failed to get call logs, falling back to IDB", (error as Error).message);
            dbMode = 'indexedDB';
            return idbService.getCallLogsFromIdb();
        }
    }
    return idbService.getCallLogsFromIdb();
}

export async function upsertCallLogs(logs: CallLog[]): Promise<void> {
    await idbService.upsertCallLogsToIdb(logs);
    if (dbMode === 'supabase') {
        try {
            await supabaseService.upsertCallLogsToSupabase(logs);
        } catch (error) {
            console.error("Supabase failed to upsert call logs", (error as Error).message);
        }
    }
}

// --- TTS GENERATIONS ---
export async function getTtsGenerations(): Promise<TtsGeneration[]> {
    if (dbMode === 'supabase') {
        try {
            const generations = await supabaseService.getTtsGenerations();
            // Also cache them in IDB for offline access
            await idbService.upsertTtsGenerationsToIdb(generations);
            return generations;
        } catch (error) {
            console.error("Supabase failed to get TTS generations, falling back to IDB", (error as Error).message);
            dbMode = 'indexedDB'; // Go offline for this session
            return idbService.getTtsGenerationsFromIdb();
        }
    }
    return idbService.getTtsGenerationsFromIdb();
}

export async function saveTtsGeneration(generationData: {
    input_text: string;
    audio_url: string;
}): Promise<TtsGeneration> {
    let newGeneration: TtsGeneration;

    if (dbMode === 'supabase') {
        try {
            newGeneration = await supabaseService.saveTtsGeneration(generationData);
        } catch (error) {
            console.error("Supabase failed to save TTS generation, saving locally.", (error as Error).message);
            dbMode = 'indexedDB';
            newGeneration = { ...generationData, id: `local-${Date.now()}`, created_at: new Date().toISOString() };
        }
    } else {
        newGeneration = { ...generationData, id: `local-${Date.now()}`, created_at: new Date().toISOString() };
    }
    
    // Always write to IDB (either the supabase-generated record or the local one)
    await idbService.upsertTtsGenerationsToIdb([newGeneration]);
    return newGeneration;
}


import { createClient } from '@supabase/supabase-js';
import { Agent, Voice, CallLog, TtsGeneration } from '../types';

const SUPABASE_URL = 'https://czqshoezorvjggfkummy.supabase.co';
const SUPABASE_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImN6cXNob2V6b3J2amdnZmt1bW15Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjAyNzcwODIsImV4cCI6MjA3NTg1MzA4Mn0.4t7cptFWSVC0NleBilfrlpoiD0SiZvrrTeLiEBWe61Q';

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// AGENTS
export const getAgentsFromSupabase = async (): Promise<Agent[]> => {
    const { data, error } = await supabase.from('agents').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    return data.map(agent => ({
        id: agent.id,
        name: agent.name,
        voice: agent.voice,
        systemPrompt: agent.systemPrompt,
        thinkingMode: agent.thinkingMode,
        avatarUrl: agent.avatarUrl,
    }));
};

export const upsertAgentsToSupabase = async (agents: Agent[]) => {
    const { error } = await supabase.from('agents').upsert(agents);
    if (error) throw error;
};

export const updateAgentInSupabase = async (agent: Agent) => {
    const { error } = await supabase.from('agents').update({
        name: agent.name,
        voice: agent.voice,
        systemPrompt: agent.systemPrompt,
        thinkingMode: agent.thinkingMode,
        avatarUrl: agent.avatarUrl,
    }).eq('id', agent.id);
    if (error) throw error;
}

// VOICES
export const getVoicesFromSupabase = async (): Promise<Voice[]> => {
    const { data, error } = await supabase.from('voices').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    return data;
};

export const upsertVoicesToSupabase = async (voices: Voice[]) => {
    const { error } = await supabase.from('voices').upsert(voices);
    if (error) throw error;
};

// CALL LOGS
export const getCallLogsFromSupabase = async (): Promise<CallLog[]> => {
    const { data, error } = await supabase.from('call_logs').select('*').order('created_at', { ascending: false });
    if (error) throw error;
    return data;
}

export const upsertCallLogsToSupabase = async (logs: CallLog[]) => {
    const { error } = await supabase.from('call_logs').upsert(logs);
    if (error) throw error;
}

// === AUDIO STORAGE ===
const AUDIO_BUCKET = 'eburon-audio';

export const uploadAgentAvatar = async (
  agentId: string,
  imageFile: File
): Promise<string> => {
  const fileExtension = imageFile.name.split('.').pop() || 'png';
  const fileName = `agent-avatars/${agentId}/avatar.${fileExtension}`;

  const { error } = await supabase.storage
    .from(AUDIO_BUCKET)
    .upload(fileName, imageFile, {
      cacheControl: '3600',
      upsert: true, // Replace if exists
    });

  if (error) throw new Error(`Avatar upload failed: ${error.message}`);

  const { data } = supabase.storage.from(AUDIO_BUCKET).getPublicUrl(fileName);
  return `${data.publicUrl}?t=${new Date().getTime()}`; // Add timestamp to break cache
};


export const uploadAudioSample = async (
  voiceName: string,
  audioBlob: Blob
): Promise<string> => {
  const fileName = `voice-previews/${voiceName.toLowerCase().replace(/ /g, '_')}_${Date.now()}.wav`;

  const { error } = await supabase.storage
    .from(AUDIO_BUCKET)
    .upload(fileName, audioBlob, {
      cacheControl: '3600',
      upsert: false,
    });

  if (error) throw new Error(`Upload failed: ${error.message}`);

  const { data } = supabase.storage.from(AUDIO_BUCKET).getPublicUrl(fileName);
  return data.publicUrl;
};

export const uploadIvrAudio = async (
  menuId: string,
  audioBlob: Blob
): Promise<string> => {
  const fileName = `ivr-audio/${menuId}.wav`;

  const { error } = await supabase.storage
    .from(AUDIO_BUCKET)
    .upload(fileName, audioBlob, {
      cacheControl: '3600',
      upsert: true,
    });

  if (error) throw new Error(`IVR upload failed: ${error.message}`);

  const { data } = supabase.storage.from(AUDIO_BUCKET).getPublicUrl(fileName);
  return data.publicUrl;
};

// === TTS STUDIO ===
const TTS_AUDIO_BUCKET_PATH = 'tts-generations';

export const uploadTtsAudio = async (
  audioBlob: Blob
): Promise<string> => {
  const fileName = `${TTS_AUDIO_BUCKET_PATH}/${Date.now()}.wav`;

  const { error } = await supabase.storage
    .from(AUDIO_BUCKET)
    .upload(fileName, audioBlob, {
      cacheControl: '3600',
      upsert: false,
    });

  if (error) throw new Error(`TTS audio upload failed: ${error.message}`);

  const { data } = supabase.storage.from(AUDIO_BUCKET).getPublicUrl(fileName);
  return data.publicUrl;
};

export const saveTtsGeneration = async (generation: {
    input_text: string,
    audio_url: string,
}): Promise<TtsGeneration> => {
    const { data, error } = await supabase.from('tts_generations').insert([generation]).select();
    if (error) throw error;
    return data[0];
};

export const getTtsGenerations = async (): Promise<TtsGeneration[]> => {
    const { data, error } = await supabase.from('tts_generations').select('*').order('created_at', { ascending: false }).limit(50);
    if (error) throw error;
    return data;
}

export enum ActiveView {
  Templates = 'Templates',
  Agents = 'Agents',
  Voices = 'Voices',
  Chatbot = 'Chatbot',
  IVR = 'IVR',
  CallLogs = 'CallLogs',
  TTSStudio = 'TTSStudio',
}

export interface Template {
  id: string;
  name: string;
  description: string;
  useCases: string[];
  systemPrompt: string;
}

export interface Agent {
  id:string;
  name: string;
  voice: string;
  systemPrompt: string;
  thinkingMode: boolean;
  avatarUrl: string | null;
}

export interface Voice {
  id: string;
  name: string;
  provider: string;
  type: 'Prebuilt' | 'Cloned';
}

export interface EburonVoice {
  id: string;
  name: string;
  description: string | null;
  public: boolean;
  tags: string[];
}

export interface EburonPersona {
    persona_id: string;
    name: string;
    system_prompt: string;
    voice_id: string;
    description: string;
}


export interface ChatMessage {
    id: string;
    role: 'user' | 'model';
    text: string;
    image?: string;
    groundingChunks?: GroundingChunk[];
    stats?: {
        tokens: number;
        speedWps: number;
        speedCps: number;
        energyKwh: number;
    };
}

export interface GroundingChunk {
    web?: {
        // FIX: Made uri and title optional to match the type from @google/genai
        uri?: string;
        title?: string;
    }
}

export interface GroundingMetadata {
    groundingChunks: GroundingChunk[];
}

export interface TranscriptSegment {
    user: 'user' | 'agent';
    text: string;
    start_time: number;
}

export interface CallLog {
  call_id: string;
  created_at: string;
  duration: number;
  from: string;
  to: string;
  recording_url: string;
  concatenated_transcript: string;
  transcript: TranscriptSegment[];
}

export interface TtsGeneration {
  id: string;
  created_at: string;
  input_text: string;
  audio_url: string;
}